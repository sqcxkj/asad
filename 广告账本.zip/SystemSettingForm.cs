﻿using LiteDB;
using System; 
using System.Data.SQLite;
//using System.Text;
//using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;
using System.Data;
//using System.Reflection;
 
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using 广告账本.Properties;
using System.Linq;
using System.Diagnostics.Eventing.Reader;
using static 广告账本.SystemSettingForm;
using System.ComponentModel;
using System.Collections.ObjectModel;
//using System.Diagnostics;

namespace 广告账本
{
    public partial class SystemSettingForm : Form
    {

        private readonly SQLiteConnection connection;
        public SystemSettingForm()
        {
            InitializeComponent();
            // 创建一个连接到Access数据库的连接对象
             connection = new SQLiteConnection("Data Source=.\\Database.db;");
        }


        public class CpType
        {
            public int _id { get; set; }
            public string ProductType { get; set; }
            public string Unit { get; set; }
            public string JijiaFangshi { get; set; }
            public string CustomerName { get; internal set; }
        }



        public class Account
        {
            public int ID { get; set; } // 在LiteDB中，主键必须是int类型，不能是INTEGER类型  
            public string CustomerName { get; set; }
            public string Filename { get; set; }
            public string ProductType { get; set; }
            public string Process { get; set; }
            public double Length { get; set; }
            public double Width { get; set; }
            public string Unit { get; set; }
            public double UnitPrice { get; set; }
            public int cpNumber { get; set; }
            public double Subtotal { get; set; }
            public double Discount { get; set; }
            public string RecordTime { get; set; }
            public string IsPaid { get; set; }
            public string payby { get; set; } // 在LiteDB中，字段必须是具体的字符类型，不能是CHAR类型  
            public string Remark { get; set; }
        }

        public class Customer
        {
            public int  ID { get; set; }
            public string CustomerName { get; set; }
            public int CustomerLevel { get; set; }
        }

        public class ProductPrice
        {
            public int  ID { get;set;}
            public string ProductType { get;set;}
            public string Process { get;set;}
            public double UnitPrice { get;set;}
            public double UnitPricet { get;set;}
            public double UnitPrices { get;set;}
            public string Unit { get;set;}
            public double lowprice { get;set;}
            public string JijiaFangshi { get;set;}
             public string lwunit {get;set;}
             
        }

        public class SystemSetting
        {

            //[BsonId]
            public int _id { get; set; }
            [BsonField("CalculationFormula")]
            public string CalculationFormula { get; set; }


            //public int SettingID { get; set; }
            [BsonField("JijiaFangshi")]
            public string JijiaFangshi { get; set; }

           

        }
        private void button1_Click(object sender, EventArgs e)
        {


            if (gsid.Text != "")
            {
                int cpid = int.Parse(gsid.Text);
                string cplx = jjfs.Text;//计价方式
                string cpgy = jjgs.Text;//及加工时
                try
                {
                    var filename = ".\\ldatabase.db";
                    using (var db = new LiteDatabase(filename))
                    {
                        var collection = db.GetCollection<SystemSetting>("SystemSettings");
                        var setting = collection.FindOne(s => s._id == cpid);

                        if (setting != null)
                        {
                            setting.JijiaFangshi = cplx;
                            setting.CalculationFormula = cpgy;
                            var success = collection.Update(setting);

                            if (success)
                            {
                                MessageBox.Show("更新成功***");
                            }
                            else
                            {
                                MessageBox.Show("没有记录被更新。");
                            }
                        }
                        else
                        {
                            MessageBox.Show("没有找到指定的设置。");
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }              
         
             }

            else
            {
                string cplx = jjfs.Text;//计价方式
                string cpgy = jjgs.Text;//计价公式
                if (jjfs.Text == "")
                {
                    _ = MessageBox.Show("类型不能为空");
                    return;
                }
                  try
                {
                    var filename = ".\\ldatabase.db";
                    using (var dba = new LiteDatabase(filename))
                    {
                       // dba.DropCollection("SystemSettings"); // 方法来删除现有的集合  
                        var collection = dba.GetCollection<SystemSetting>("SystemSettings");
                        var SystemSettings = new SystemSetting
                        {
                           // _id = 1,
                            CalculationFormula =cpgy,
                            JijiaFangshi = cplx,

                        };
                        // 插入新的CpType对象到集合中    
                        collection.Insert(SystemSettings);
                        MessageBox.Show("OK");
                    }

                }
                catch (Exception ex)
                {
                    _ = MessageBox.Show("发生错误：" + ex.Message);
                }


            }

            gsid.Text = "";

            jjfs.Text = "";
            jjgs.Text = "";
            anniuwenzi();
            RefreshData();


            //if (gsid.Text != "")
            //{
            //    string cpid = gsid.Text;
            //    string cplx = jjfs.Text;
            //    string cpgy = jjgs.Text;
            //    try
            //    {
            //        // 打开litedb数据库连接  
            //        connection.Open();
            //        // 更新记录  
            //        string sql = "UPDATE SystemSettings SET jijiafangshi=@jjfs, CalculationFormula=@jjgs  WHERE SettingID = @SettingID";
            //        SQLiteCommand command = new SQLiteCommand(sql, connection);
            //        _ = command.Parameters.AddWithValue("@jjfs", cplx);
            //        _ = command.Parameters.AddWithValue("@jjgs", cpgy);
            //        _ = command.Parameters.AddWithValue("@SettingID", cpid);
            //        int rowsAffected = command.ExecuteNonQuery();
            //        if (rowsAffected == 0)
            //        {
            //            _ = MessageBox.Show("没有记录被更新。");
            //        }
            //        // 关闭数据库连接  
            //        connection.Close();
            //        // 添加操作成功后的代码块中
            //        // 关联更新按钮的Click事件处理程序

            //        _ = MessageBox.Show("更新成功");
            //        RefreshData();
            //    }
            //    catch (Exception ex)
            //    {
            //        _ = MessageBox.Show(ex.Message);
            //    }
            //}
            //else
            //{
            //    string cplx = jjfs.Text;
            //    string cpgy = jjgs.Text;
            //    if (jjfs.Text == "")
            //    {
            //        _ = MessageBox.Show("类型不能为空");
            //        return;
            //    }
            //    try
            //    {
            //        // 如果输入框为空，且输入的数字不为0，则插入新字符并标记事件为已处理
            //        SQLiteConnection connection = new SQLiteConnection("Data Source=.\\Database.db;Version=3;");
            //        connection.Open();
            //        SQLiteCommand insertCommand = new SQLiteCommand("INSERT INTO SystemSettings (jijiafangshi, CalculationFormula) VALUES (@jjfs, @jjgs)", connection);
            //        _ = insertCommand.Parameters.AddWithValue("@jjfs", cplx);
            //        _ = insertCommand.Parameters.AddWithValue("@jjgs", cpgy);
            //        int rowsAffected = insertCommand.ExecuteNonQuery();
            //        if (rowsAffected > 0)
            //        {
            //            // 刷新 ListView
            //            _ = MessageBox.Show("添加成功！");
            //            RefreshData();
            //            // 添加操作成功后的代码块中
            //            // 关联更新按钮的Click事件处理程序
            //            //pictureBox1.Visible = true; // 显示 PictureBox
            //            //timer1.Start(); // 启动定时器
            //        }
            //        else
            //        {
            //            _ = MessageBox.Show("添加失败！");
            //        }
            //        connection.Close();
            //    }
            //    catch (Exception ex)
            //    {
            //        _ = MessageBox.Show("发生错误：" + ex.Message);
            //    }
            //}
            //gsid.Text = "";

            //jjfs.Text = "";
            //jjgs.Text = "";
            //anniuwenzi();
            //RefreshData();
        }

        private void SystemSettingForm_Load(object sender, EventArgs e)
        {
            // 读取备份路径文本文件  
            string backupPath = "";
            if (File.Exists("BackupPath.txt"))
            {
                backupPath = File.ReadAllText("BackupPath.txt");
            }
            bflj.Text = "备份路径" + backupPath;

            RefreshData();
            anniuwenzi();
            anniuwenzit();
            return;
        }

        private void dataGridView_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {



            if (e.RowIndex >= 0 && e.RowIndex < dataGridView.RowCount)
            {
                //DataGridViewRow row = dataGridView.Rows[e.RowIndex];
                // 这里可以处理row的相关操作  
                if (dataGridView.Rows.Count > 0 && dataGridView.Columns.Count > 0)
                {
                    // DataGridViewCell cell = dataGridView.Rows[e.RowIndex].Cells[0];
                    // MessageBox.Show(cell.Value.ToString());
                    gsid.Text = dataGridView.Rows[e.RowIndex].Cells[0].Value.ToString();//公式ID
                    jjfs.Text = dataGridView.Rows[e.RowIndex].Cells[2].Value.ToString();//计价方式
                    jjgs.Text = dataGridView.Rows[e.RowIndex].Cells[1].Value.ToString();//计价公式



                }
                else
                {
                    _ = MessageBox.Show("DataGridView中没有行或单元格");
                }

            }
            else
            {
                // 索引超出范围的错误处理  
                return;

            }

            anniuwenzi();
        }




        private void anniuwenzi()
        {

            if (gsid.Text != "")
            {
                insbtn.Text = "提交更新";
                insbtn.BackColor = Color.LightPink;

            }
            else
            {
                insbtn.Text = "确认添加";
                insbtn.BackColor = Color.LightGreen;

            }

        }
       
        private void RefreshData()
        {

            // 打开连接

            using (var db = new LiteDatabase(".\\ldatabase.db"))

            {

                // 获取系统设置集合

                var systemSettings = db.GetCollection("systemsettings");

              


                // 获取系统设置数据
                var systemSettingsData = systemSettings.FindAll()
     .Select(doc => new SystemSetting
     {
         _id = doc["_id"].AsInt32,
         CalculationFormula = doc["CalculationFormula"].AsString,
         JijiaFangshi = doc["JijiaFangshi"].AsString,
         // 其他属性
          }).ToList();


                // 获取CpType集合

                var cpType = db.GetCollection("CpType");

                // 获取CpType数据

                var cpTypeData = cpType.FindAll()
     .Select(doc => new CpType     {
         _id = doc["_id"].AsInt32,
         ProductType = doc["ProductType"].AsString,
         Unit = doc["Unit"].AsString,
         JijiaFangshi = doc["JijiaFangshi"].AsString,
         // 其他属性
     }).ToList();
               

                // 绑定 DataGridView 控件

                dataGridView.DataSource = new BindingList<SystemSetting>(systemSettingsData);
                dataGridView1.DataSource = new BindingList<CpType>(cpTypeData);
            }



        }

        private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {


            if (e.RowIndex >= 0 && e.RowIndex < dataGridView1.RowCount)
            {

                if (dataGridView1.Rows.Count > 0 && dataGridView1.Columns.Count > 0)
                {
                    flid.Text = dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString();//分类id
                    jjfs1.Text = dataGridView1.Rows[e.RowIndex].Cells[3].Value.ToString();//计价方式
                    spfl.Text = dataGridView1.Rows[e.RowIndex].Cells[1].Value.ToString();//商品分类
                    dw.Text = dataGridView1.Rows[e.RowIndex].Cells[2].Value.ToString();



                }
                else
                {
                    _ = MessageBox.Show("DataGridView1中没有行或单元格");
                }

            }
            else
            {
                // 索引超出范围的错误处理  
                return;

            }
            anniuwenzit();
        }

        private void gxfl_Click(object sender, EventArgs e)    //商品分类
        {
            if (flid.Text != "")
            {

                int cpid = int.Parse(flid.Text); //id
                string cpjjfs = jjfs1.Text; //分类
                string cpfl = spfl.Text;//
                string cpdw = dw.Text;
                try
                {
                    //相关内容给
                    //更新数据代码
                    var filename = ".\\ldatabase.db";
                    using (var db = new LiteDatabase(filename))
                    {
                        var collection = db.GetCollection<CpType>("CpType");
                        var Product = collection.FindOne(s => s._id == cpid);  //此处要更改id的数据类型为int类型

                        if (Product != null)
                        {
                            Product.ProductType = cpfl;
                            Product.Unit = cpdw;
                            Product.JijiaFangshi = cpjjfs;
                            var success = collection.Update(Product);

                            if (success)
                            {
                                MessageBox.Show("更新成功***");
                            }
                            else
                            {
                                MessageBox.Show("没有记录被更新。");
                            }
                        }
                        else
                        {
                            MessageBox.Show("没有找到指定的设置。");
                        }
                    }




                }
                catch (Exception ex)
                {
                    _ = MessageBox.Show(ex.Message);
                }


            }
            else
            {
                //_ = flid.Text; //id
                string cpjjfs = jjfs1.Text; //分类
                string cpfl = spfl.Text;//
                string cpdw = dw.Text;



                // 如果输入框为空，且输入的数字不为0，则插入新字符并标记事件为已处理
                if (jjfs1.Text == "")
                {

                    _ = MessageBox.Show("类型不能为空");
                    return;
                }

 
                try
                {

                    //插入数据代码
                    var filename = ".\\ldatabase.db";
                    using (var dba = new LiteDatabase(filename))
                    {
                        // dba.DropCollection("SystemSettings"); // 方法来删除现有的集合  
                        var collection = dba.GetCollection<CpType>("CpType");
                        var CpType = new CpType
                        {
                            ProductType = cpfl,
                            Unit = cpdw,
                            JijiaFangshi = cpjjfs
                        };
                        // 插入新的CpType对象到集合中    
                        collection.Insert(CpType);
                        MessageBox.Show("OK");
                    }

                }
                catch (Exception ex)
                {
                    _ = MessageBox.Show("发生错误：" + ex.Message);
                }
                finally
                {
                    connection.Close();
                }

            }
            RefreshData();
            flid.Text = "";
            jjfs1.Text = "";
            spfl.Text = "";
            dw.Text = "";
            anniuwenzit();
        }




        private void anniuwenzit()
        {

            if (flid.Text != "")
            {
                gxfl.Text = "提交更新";
                gxfl.BackColor = Color.LightPink;

            }
            else
            {
                gxfl.Text = "确认添加";
                gxfl.BackColor = Color.LightGreen;

            }

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            // 定义备份文件的路径  
            string backupFilePath = ".\\Database.db";



            // 读取备份路径文本文件  
            string backupPath = "";
            if (File.Exists("BackupPath.txt"))
            {
                backupPath = File.ReadAllText("BackupPath.txt");
            }

            // 判断备份路径是否为空  
            if (string.IsNullOrEmpty(backupPath))
            {
                // 如果备份路径为空，显示文件夹选择对话框  
                FolderBrowserDialog folderBrowser = new FolderBrowserDialog();
                if (folderBrowser.ShowDialog() == DialogResult.OK)
                {
                    // 获取选择的文件夹路径  
                    backupPath = folderBrowser.SelectedPath;

                    // 将备份路径写入文本文件  
                    File.WriteAllText("BackupPath.txt", backupPath);
                }
                else
                {
                    // 用户取消了文件夹选择对话框，不执行备份操作  
                    return;
                }
            }

            // 获取当前日期时间  
            string dateTimeString = DateTime.Now.ToString("yyyyMMddHHmmss");

            // 定义备份文件的路径  
            // string backupFilePath = Path.Combine(backupPath, $"Database_{dateTimeString}.db");

            // 创建ProcessStartInfo对象，指定要执行的命令  
            ProcessStartInfo startInfo = new ProcessStartInfo
            {
                FileName = "cmd.exe",
                Arguments = $"/C copy \"{backupFilePath}\" \"{backupPath}\\Database_Backup_{dateTimeString}.db\"",
                WindowStyle = ProcessWindowStyle.Hidden,
                CreateNoWindow = true,
                UseShellExecute = false
            };

            // 创建Process对象，并启动进程  
            Process process = new Process { StartInfo = startInfo };
            _ = process.Start();
            process.WaitForExit();

            // 显示备份成功的消息  
            _ = MessageBox.Show("数据库备份成功！");
 
        }

        private void button2_Click(object sender, EventArgs e)           //初始化数据库表
        {

            

            var filename = ".\\ldatabase.db";
            
            
            using (var db = new LiteDatabase(filename))
            {  // 获取集合（表）  
                 db.DropCollection("Accounts");
                var collection = db.GetCollection<Account>("Accounts");
                // 创建一个新的账户对象  
                var account = new Account
                {
                    //AccountID = 1, // 这里只是一个示例，你可以根据需求设置其他的值  
                    CustomerName = "散单",
                    Filename = "example.txt",
                    ProductType = "写真",
                    Process = "腹板",
                    Length = 10.0,
                    Width = 5.0,
                    Unit = "cm",
                    UnitPrice = 28,
                    cpNumber = 10,
                    Subtotal = 100.0,
                    Discount = 0,
                    RecordTime = DateTime.Now.ToString(), // 这里只是一个示例，你可以根据需求设置其他的值  
                    IsPaid = "否",
                    payby = "微信", // 这里只是一个示例，你可以根据需求设置其他的值  
                    Remark = "This is an example account."
                };
                // 插入新的账户到集合中  
                collection.Insert(account);
                MessageBox.Show("OK");
            }
           
             

            using (var dba = new LiteDatabase(filename))
            {
                dba.DropCollection("CpType"); // 方法来删除现有的集合  
                var collection = dba.GetCollection<CpType>("CpType");
                var cpType = new CpType 
                {
                    _id = 1,
                    ProductType = "喷绘",
                    Unit = "平方",
                    JijiaFangshi = "面积"
                };
                // 插入新的CpType对象到集合中    
                collection.Insert(cpType);
                MessageBox.Show("OK");
            }

            using (var dba = new LiteDatabase(filename))
            {
                dba.DropCollection("Customers"); // 方法来删除现有的集合  
                var collection = dba.GetCollection<Customer>("Customers");
                var customer = new Customer
                {
                     ID = 1,
                    CustomerName="散单",
                    CustomerLevel=1

                };
                // 插入新的CpType对象到集合中    
                collection.Insert(customer);
                MessageBox.Show("OK");
            }


            using (var dba = new LiteDatabase(filename))
            {
                dba.DropCollection("ProductPrices"); // 方法来删除现有的集合  
                var collection = dba.GetCollection<ProductPrice>("ProductPrices");
                var ProductPrices = new ProductPrice
                {
                    ID = 1,
                    ProductType = "喷绘",
                    Process = "三旗布",
                    UnitPrice=7,
                    UnitPricet=0,
                    UnitPrices=0,
                    Unit="平方",
                    lowprice=0,
                    JijiaFangshi="面积",
                    lwunit="cm"

                };
                // 插入新的CpType对象到集合中    
                collection.Insert(ProductPrices);
                MessageBox.Show("OK");
            }



            using (var dba = new LiteDatabase(filename))
            {
                dba.DropCollection("SystemSettings"); // 方法来删除现有的集合  
                var collection = dba.GetCollection<SystemSetting>("SystemSettings");
                var SystemSettings = new SystemSetting
                {
                     _id = 1,
                    CalculationFormula = "长*数量*单价",               
                    JijiaFangshi = "长度",
               
                };
                // 插入新的CpType对象到集合中    
                collection.Insert(SystemSettings);
                MessageBox.Show("OK");
            }





 

         
    }

}
    
}
