﻿namespace 广告账本
{
    partial class AddRecordForm
    {
        private System.Windows.Forms.ComboBox CustomerNamebox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox ProductIDbox;
        private System.Windows.Forms.Label ProductIDlabel;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox Processbox;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox Lengthtext;
        private System.Windows.Forms.TextBox Widthtext;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox Unittext;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox UnitPricetext;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox Subtotaltext;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox Discounttext;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ComboBox IsPaidbox;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.DataGridView dataGridView;
        private System.Windows.Forms.Button Addbutton;
        private System.Windows.Forms.TextBox Numbertext;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox filename;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Button yesadd;
        private System.Windows.Forms.Label totalprice;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label danwei;
        private System.Windows.Forms.Label danwei1;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.ComboBox paybybox;
        private System.Windows.Forms.Label label16;
    }
}