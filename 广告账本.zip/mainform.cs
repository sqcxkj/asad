﻿
using System;
using System.Linq;
using System.Windows.Forms;
using System.Data.SQLite;
using System.Drawing;
using LiteDB;
 
using System.Collections.Generic;

using Timer = System.Windows.Forms.Timer;
using System.Security.Principal;
 
using static System.Windows.Forms.ListViewItem;

namespace 广告账本
{

   


    public partial class mainform : Form
    {
        public mainform()
        {
            InitializeComponent();
            // 监听应用程序的FormClosing事件


        }


        private void AddRecordButton_Click(object sender, EventArgs e)
        {
            // 创建一个QueryForm对象，并显示窗口
            AddRecordForm addRecordForm = new AddRecordForm();
            addRecordForm.Show();
        }

        public class Account
        {

            public int AccountID { get; set; } // 在LiteDB中，主键必须是int类型，不能是INTEGER类型  
            public string CustomerName { get; set; }
            public string Filename { get; set; }
            public string ProductType { get; set; }
            public string Process { get; set; }
            public double Length { get; set; }
            public double Width { get; set; }
            public string Unit { get; set; }
            public double UnitPrice { get; set; }
            public int cpNumber { get; set; }
            public double Subtotal { get; set; }
            public double Discount { get; set; }
            public string RecordTime { get; set; }
            public string IsPaid { get; set; }
            public string payby { get; set; } // 在LiteDB中，字段必须是具体的字符类型，不能是CHAR类型  
            public string Remark { get; set; }
        }

        private void mainform_Load(object sender, EventArgs e)
        {

            UpdateListViewTag();

            sx();
            //*******

        }

        private void timer_Tick(object sender, EventArgs e)
        {
            // 使用当前系统时间更新时间标签的文本
            shijian.Text = "当前系统时间：" + DateTime.Now.ToString();
        }

        private void unpaidListView_DoubleClick(object sender, EventArgs e)


        {
            // 设置双击时选定行的行号，和倍选中的客户名所在列sunitems[1]
            string guestname = unpaidListView.SelectedItems[0].SubItems[1].Text;
            QueryForm queryForm = new QueryForm(guestname);
            queryForm.Show();
        }

        private void QueryButton_Click(object sender, EventArgs e)
        {
            // 创建一个QueryForm对象，并显示窗口
            QueryForm queryForm = new QueryForm();
            queryForm.Show();
        }

        private void addproduct_Click(object sender, EventArgs e)
        {

            AddProductForm addProductForm = new AddProductForm();
            addProductForm.Show();
        }



        private void UpdateListViewTag()  //更新数据*************************************
        {


            // 连接到数据库
            using (var db = new LiteDatabase(".\\ldatabase.db"))
            {
                // 设置ListView控件的View属性为Details
                unpaidListView.View = View.Details;

                // 添加客户名、未结账金额的列
                unpaidListView.Columns.Add("序号", 80, HorizontalAlignment.Left);
                unpaidListView.Columns.Add("客户名", 140, HorizontalAlignment.Left);
                unpaidListView.Columns.Add("未结账金额", 140, HorizontalAlignment.Left);

                // 获取 Accounts 集合
                var collection = db.GetCollection<Account>("Accounts");

                // 查询未结账客户名、未结账金额的信息
                var query = collection.Find(Query.EQ("IsPaid", "否"))
                       .GroupBy(x => x.CustomerName)
                       .Select(g => new {
                           CustomerName = g.Key,
                           TotalUnpaidAmount = g.Sum(x => x.Subtotal - x.Discount)
                       });

                // 遍历查询结果，将未结账客户名、未结账金额添加到ListView的每一行中
                int serialNumber = 1;
                decimal totalUnpaidAmount = 0.00m;
                foreach (var result in query)
                {
                    var item = new ListViewItem(new string[] { serialNumber.ToString(), result.CustomerName, result.TotalUnpaidAmount.ToString("#,##0.00") + "元" })
                    {
                        Tag = result.CustomerName
                    };
                    unpaidListView.Items.Add(item);

                    serialNumber++;
                  //  totalUnpaidAmount = result.TotalUnpaidAmount;
                }

                label1.Text = "当前未结账单总计(￥)：" + totalUnpaidAmount.ToString("#,##0.00");

                // 确保资源被正确释放
                collection = null;
            }


        }

        private void sx()
        {


            //创建liteDB数据库链接
            string filename = ".\\ldatabase.db";

            using (var db = new LiteDatabase(filename))
            {
                // 获取集合（表）  
                var collection = db.GetCollection<BsonDocument>("Accounts");

                // 查询未结账客户名、未结账金额和账单时间的信息  
                //var query = collection.Find(Query.All("isPaid", "否")).SortByDescending("RecordTime").Limit(20);
              
                var query = collection.Find(Query.All());

                query = query.OrderByDescending(x => x["RecordTime"]);

                foreach (var document in query)
                {
                    // ...  
                }

                // 设置ListView控件的View属性为Details  
                listView1.View = View.Details;

                // 添加客户名、未结账金额的列  
                _ = listView1.Columns.Add("序号", 40, HorizontalAlignment.Left);
                _ = listView1.Columns.Add("客户名", 80, HorizontalAlignment.Left);
                _ = listView1.Columns.Add("广告类型", 100, HorizontalAlignment.Left);
                _ = listView1.Columns.Add("尺寸规格", 110, HorizontalAlignment.Left);
                _ = listView1.Columns.Add("小计金额", 80, HorizontalAlignment.Left);
                _ = listView1.Columns.Add("是否付款", 80, HorizontalAlignment.Left);
                _ = listView1.Columns.Add("下单时间", 140, HorizontalAlignment.Left);

                // 遍历查询结果，将未结账客户名、未结账金额添加到ListView的每一行中  
                int serialnew = 1;
                int colornum = 0;

                foreach (var document in query)
                {
                    string khm = document["CustomerName"].AsString;
                    string ptn = document["ProductType"].AsString;
                    string ptt = document["Process"].AsString;
                    double len = document["Length"].AsDouble;
                    double wid = document["Width"].AsDouble;
                    double sub = document["Subtotal"].AsDouble;
                    string pay = document["IsPaid"].AsString;
                    string tim = document["RecordTime"].AsString;

                    ListViewItem item = new ListViewItem(new string[] { serialnew.ToString(), khm, ptn + ptt, len.ToString() + " * " + wid.ToString(), sub.ToString(), pay, tim.ToString() });
                    item.BackColor = pay == "是" ? Color.LightGreen : Color.LightYellow;
                    _ = listView1.Items.Add(item);

                    serialnew++;
                    colornum++;
                }
            }


             
        }
        private void addguestname_Click(object sender, EventArgs e)
        {


            // 创建一个QueryForm对象，并显示窗口
            guestname guestname = new guestname();
            guestname.Show();

        }

        private void exitbut_Click(object sender, EventArgs e)
        {
            Application.Exit(); // 退出应用程序


        }

        private void syssetup_Click(object sender, EventArgs e)
        {

            // 创建一个QueryForm对象，并显示窗口
            SystemSettingForm SystemSettingForm = new SystemSettingForm();
            SystemSettingForm.Show();
        }

        private void mainform_FormClosing(object sender, FormClosingEventArgs e)
        {


            int activeWindowCount = 0;


            // 统计活动窗口数量（除了主窗口）
            foreach (Form form in Application.OpenForms)
            {
                if (form != this && form.Visible)
                {
                    activeWindowCount++;
                }
            }

            // 如果存在多个活动窗口，给出提示并取消关闭操作
            if (activeWindowCount > 0)
            {
                _ = MessageBox.Show("请关闭所有窗口后再关闭主窗口。");
                e.Cancel = true;
                return;
            }
            // 如果没有其他活动窗口，确认退出
            DialogResult result = MessageBox.Show("是否确认退出应用程序？", "确认退出", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.No)
            {
                e.Cancel = true; // 退出应用程序
            }
        }



        private void button1_Click(object sender, EventArgs e)
        {
            listView1.Items.Clear();
            listView1.Columns.Clear();
            unpaidListView.Items.Clear();
            unpaidListView.Columns.Clear(); // 清除表头  

            UpdateListViewTag();
            sx();
            // MessageBox.Show("刷新成功");
        }
    }

}
