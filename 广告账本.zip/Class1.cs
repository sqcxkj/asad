﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace 广告账本
{
    internal class Class1
    {
        public class Account
        {

            public int AccountID { get; set; } // 在LiteDB中，主键必须是int类型，不能是INTEGER类型  
            public string CustomerName { get; set; }
            public string Filename { get; set; }
            public string ProductType { get; set; }
            public string Process { get; set; }
            public double Length { get; set; }
            public double Width { get; set; }
            public string Unit { get; set; }
            public double UnitPrice { get; set; }
            public int cpNumber { get; set; }
            public double Subtotal { get; set; }
            public double Discount { get; set; }
            public string RecordTime { get; set; }
            public string IsPaid { get; set; }
            public string payby { get; set; } // 在LiteDB中，字段必须是具体的字符类型，不能是CHAR类型  
            public string Remark { get; set; }
        }
    }
}
