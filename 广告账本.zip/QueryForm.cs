﻿using System;
using System.Data;
using System.Data.SQLite;
using System.Drawing;
using LiteDB;
using System.IO;
using System.Windows.Forms;
using System.Linq;
using System.ComponentModel;
using static 广告账本.SystemSettingForm;
using System.Collections.ObjectModel;

namespace 广告账本
{
    public partial class QueryForm : Form
    {
        private readonly SQLiteConnection connection;
        private readonly string guestName;

        public QueryForm()
        {
            InitializeComponent();
                         
        }

         

        // 接受一个参数的构造函数，用于从父窗体传递查询条件
        public QueryForm(string condition) : this()
        {
            // 初始化 _guestName 字段
            guestName = condition;

            // 在此处使用传入的查询条件初始化各个控件
            CustomerNamebox.Text = guestName;

            // ...
        }
        // 窗体加载事件
        private void QueryForm_Load(object sender, EventArgs e)
        {// 创建一个连接到Access数据库的连接对象
         //SQLiteConnection connection = new SQLiteConnection("Data Source=.\\Database.db;Version=3;");
         //// 检查 CustomerNamebox 是否为空，如果不为空则返回
         //string customerName = CustomerNamebox.Text;
         //if (!string.IsNullOrEmpty(CustomerNamebox.Text))
         //{
         //    // 打开数据库连接
         //    connection.Open();

            //    // 查询符合条件的记录
            //    SQLiteCommand command = new SQLiteCommand("SELECT AccountID AS 记录, CustomerName AS 客户名, Filename AS 文件名, ProductType AS 类型, Length AS 长度, Width AS 宽度, Unit AS 单位, UnitPrice AS 单价, cpNumber AS 数量, Subtotal AS 小计, Discount AS 优惠, RecordTime AS 时间, IsPaid AS 是否结账, payby AS 付款方式,Remark AS 备注 FROM Accounts WHERE CustomerName = @customerName AND IsPaid = '否'", connection);
            //    _ = command.Parameters.AddWithValue("@customerName", customerName);

            //    SQLiteDataAdapter adapter = new SQLiteDataAdapter(command);
            //    DataTable dataTable = new DataTable();
            //    _ = adapter.Fill(dataTable);

            //    //清空DataGridView原有数据
            //    //将查询结果绑定到DataGridView
            //    if (dataGridView.DataSource != null)
            //    {
            //        dataGridView.DataSource = null;
            //        dataGridView.Rows.Clear();
            //    }

            //    if (dataTable.Rows.Count > 0)
            //    {
            //        dataGridView.DataSource = dataTable;
            //        string pay = dataGridView.Rows[0].Cells[12].Value.ToString();
            //        dataGridView.DefaultCellStyle.BackColor = pay == "是" ? Color.GreenYellow : Color.LightYellow;
            //    }

            //    // 关闭数据库连接
            //    connection.Close();
            //}



            //  using(var db= new LiteDatabase(".\\ldatabase.db"))
            //{
            //    //    // 获取ProductPrices集合  
            //    var customername = db.GetCollection<Customer>("Customers");

            //    // 获取集合productjihe中的数据并转换为CpType对象列表  
            //    var typelist = customername.FindAll()
            //        .Select(doc=> new CpType
            //        {
            //            //_id = doc["_id"].AsInt32,
            //            CustomerName = doc["Customers"].AsString,  //从集合DOC中获取相应字段的值
            //           // Unit = doc["Unit"].AsString,
            //           // JijiaFangshi = doc["JijiaFangshi"].AsString
            //            }

            //        )
            //        .ToList();

            //    // 绑定 ComboBox 控件  
            //    CustomerNamebox.DataSource = new BindingList<CpType>(typelist);
            //    CustomerNamebox.DisplayMember = "ProductType"; // 设置在列表中显示的成员  
            //  //  producttype.ValueMember = "_id"; // 设置作为实际值的成员  

            //}
            RefreshData();
            jisuan();

        }


        private void dataGridView_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {


            // 获取点击的单元格的行和列索引
            int rowIndex = e.RowIndex;
            int columnIndex = e.ColumnIndex;
            DataGridViewCell cell = dataGridView.Rows[e.RowIndex].Cells[e.ColumnIndex];

            _ = MessageBox.Show(cell.Value.ToString());
            // 获取更新后的值
            object cellValue = dataGridView.Rows[rowIndex].Cells[columnIndex].Value;

            // 更新数据库中的记录
            string customerName = dataGridView.Rows[rowIndex].Cells["客户名"].Value.ToString();
            string recordTime = dataGridView.Rows[rowIndex].Cells["时间"].Value.ToString();
            string columnName = dataGridView.Columns[columnIndex].HeaderText;
            string newValue = cellValue.ToString();

            // 创建一个连接到SQLite数据库的连接对象
            SQLiteConnection connection = new SQLiteConnection("Data Source=.\\Database.db;");

            // 打开数据库连接
            connection.Open();

            // 更新记录
            string sql = "UPDATE Accounts SET " + columnName + " = @newValue WHERE CustomerName = @customerName AND RecordTime = @recordTime";
            SQLiteCommand command = new SQLiteCommand(sql, connection);
            _ = command.Parameters.AddWithValue("@newValue", newValue);
            _ = command.Parameters.AddWithValue("@customerName", customerName);
            _ = command.Parameters.AddWithValue("@recordTime", recordTime);
            _ = command.ExecuteNonQuery();

            // 关闭数据库连接
            connection.Close();



        }


        private void searchButton_Click(object sender, EventArgs e)
        {//查询全部
         // 创建一个连接到Access数据库的连接对象
         //SQLiteConnection connection = new SQLiteConnection("Data Source=.\\Database.db;Version=3;");

            // 打开数据库连接
            // connection.Open();
            string customerName = CustomerNamebox.Text;


            // 获取数据并绑定到DataGridView控件

            using (var db = new LiteDatabase(".\\ldatabase.db"))
            {
                var collection = db.GetCollection<Account>("Accounts");
                var query = collection.Query().Where(a => a.CustomerName == customerName);
                var Accountsdata = query.ToList();

                //清空DataGridView原有数据
                //将查询结果绑定到DataGridView
                if (dataGridView.DataSource != null)
                {
                    dataGridView.DataSource = null;
                    dataGridView.Rows.Clear();
                }


                dataGridView.DataSource = new BindingList<Account>(Accountsdata);
            }












            jisuan();


        }

        private void button1_Click(object sender, EventArgs e)
        {
            // 打开“另存为”文件对话框
            SaveFileDialog saveFileDialog = new SaveFileDialog
            {
                Filter = "CSV 文件 (*.csv)|*.csv|所有文件 (*.*)|*.*",
                FileName = "DataGridView.csv"
            };

            if (saveFileDialog.ShowDialog() == DialogResult.OK)
            {
                // 创建 CSV 文件并写入列标题
                using (StreamWriter streamWriter = new StreamWriter(saveFileDialog.FileName, false, System.Text.Encoding.UTF8))
                {
                    string headerRow = "";

                    // 循环每一列，并用逗号分隔添加到标题行中
                    foreach (DataGridViewColumn dgvColumn in dataGridView.Columns)
                    {
                        if (!dgvColumn.Visible)
                        {
                            continue;
                        }

                        if (!string.IsNullOrEmpty(headerRow))
                        {
                            headerRow += ",";
                        }

                        headerRow += dgvColumn.HeaderText;
                    }

                    streamWriter.WriteLine(headerRow);

                    // 循环每一行并写入到 CSV 文件
                    foreach (DataGridViewRow dgvRow in dataGridView.Rows)
                    {
                        if (!dgvRow.IsNewRow)
                        {
                            string dataRow = "";

                            // 循环每一列，并用逗号分隔添加到数据行中
                            foreach (DataGridViewCell cell in dgvRow.Cells)
                            {
                                if (cell.ColumnIndex >= dataGridView.Columns.Count || !dataGridView.Columns[cell.ColumnIndex].Visible)
                                {
                                    continue;
                                }

                                if (!string.IsNullOrEmpty(dataRow))
                                {
                                    dataRow += ",";
                                }

                                dataRow += cell.Value.ToString().Replace(",", "，").Replace("\r", "").Replace("\n", "");
                            }

                            streamWriter.WriteLine(dataRow);
                        }
                    }
                }

                _ = MessageBox.Show("导出成功！", "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

        }

        private void closebut_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {

            bool isDeleteSuccess = false;
            using (var db = new LiteDatabase(".\\ldatabase.db"))
            {
                // 创建集合（类似于SQL中的表）    
                var collection = db.GetCollection<Account>("accounts");

                if (dataGridView != null && dataGridView.Rows != null)
                {
                    DialogResult result = MessageBox.Show("确定要删除所有数据吗？", "确认删除", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                    if (result == DialogResult.Yes)
                    {
                        if (dataGridView.Rows.Count > 0)
                        {
                            foreach (DataGridViewRow row in dataGridView.Rows)
                            {
                                if (row.Cells["CustomerName"].Value != null && row.Cells["RecordTime"].Value != null)
                                {
                                    string customerName = row.Cells["CustomerName"].Value.ToString();
                                    string recordTime = row.Cells["RecordTime"].Value.ToString();

                                    // 删除Accounts表中符合条件的记录  
                                   
                                    var documentToDelete = collection.Find(x => x.RecordTime == recordTime);
                                    if (documentToDelete != null)
                                    {
                                        collection.DeleteMany(x => x.RecordTime == recordTime);
                                        isDeleteSuccess = true;
                                    }
                                }
                            }

                            // 清空DataGridView中的数据  
                            dataGridView.DataSource = null;
                            dataGridView.Rows.Clear();
                        }
                        else
                        {
                            MessageBox.Show("DataGridView没有任何行数据。");
                        }
                    }
                }
                else
                {
                    MessageBox.Show("DataGridView或Rows为空。");
                }
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            string customerName = CustomerNamebox.Text;

            using (var db = new LiteDatabase(".\\ldatabase.db"))
            {
                var collection = db.GetCollection<Account>("Accounts");
                var query = collection.Query().Where(a => a.CustomerName == customerName && a.IsPaid == "否");
                var Accountsdata = query.ToList();
                dataGridView.DataSource = new BindingList<Account>(Accountsdata);
            }


            //// 删除数据后重新获取数据并绑定到DataGridView控件
            //using (var db = new LiteDatabase(".\\ldatabase.db"))
            //{
            //    var collection = db.GetCollection<Account>("Accounts");
            //    var Accountsdata = collection.FindAll().ToList();
            //    dataGridView.DataSource = new BindingList<Account>(Accountsdata);
            //}





            jisuan();


        }

        private void button1_Click_1(object sender, EventArgs e)
        {


            string customerName = CustomerNamebox.Text;
            using (var db = new LiteDatabase(".\\ldatabase.db"))
            {
                var collection = db.GetCollection<Account>("Accounts");
                var query = collection.Query().Where(a => a.CustomerName == customerName && a.IsPaid == "是");
                var Accountsdata = query.ToList();

                //清空DataGridView原有数据

                if (dataGridView.DataSource != null)
                {
                    dataGridView.DataSource = null;
                    dataGridView.Rows.Clear();
                }
                //将查询结果绑定到DataGridView
                dataGridView.DataSource = new BindingList<Account>(Accountsdata);



                //string pd = "";




                //// 获取需要修改的单元格的样式  
            }


            jisuan();
        }


        private void CustomerNamebox_MouseClick(object sender, MouseEventArgs e)//建立客户姓名下拉列表
        { // 使用 LiteDatabase 类创建一个新的数据库连接实例，连接到一个名为 ldatabase.db 的文件数据库  
          // 数据库的连接被封装在一个 using 语句块中，这意味着在代码执行完毕后，数据库连接将会被自动关闭  
            using (var db = new LiteDatabase(".\\ldatabase.db"))
            {
                // 通过数据库连接获取一个名为 "Customer" 的集合（类似于传统数据库中的表）  
                // LiteDatabase 使用 BsonDocument 作为集合中的文档类型  
                var namelist = db.GetCollection<BsonDocument>("Customers");

                // 使用 FindAll() 方法查询 "Customer" 集合中的所有文档（也就是所有客户）  
                // 然后通过 Select() 方法将每个文档转换为一个新的 Customer 对象  
                // 这个 Customer 对象中的 CustomerName 属性被设置为原文档中 "CustomerName" 字段的值  
                // 其他属性...则被设置为原文档的其他字段的值（具体哪些字段取决于 Customer 类的定义）  
                var typelist = namelist.FindAll()
                    .Select(doc => new Customer
                    {
                        CustomerName = doc["CustomerName"].AsString,  //从集合DOC中获取相应字段的值    
                                                                      // other properties...    
                    })
                    .ToList();

                // 将得到的 Customer 对象列表赋值给 CustomerNamebox 的 DataSource 属性  
                // 这意味着 CustomerNamebox 将展示这个列表中的所有 Customer 对象  
                CustomerNamebox.DataSource = new BindingList<Customer>(typelist);

                // 设置 CustomerNamebox 的 DisplayMember 属性为 "CustomerName"  
                // 这意味着在 CustomerNamebox 中将显示每个 Customer 对象的 CustomerName 属性的值，而不是显示整个 Customer 对象  
                CustomerNamebox.DisplayMember = "CustomerName"; // 设置在列表中显示的成员    
                                                                //  producttype.ValueMember = "_id"; // 设置作为实际值的成员    

            }


        }

        private void dataGridView_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {

            if (e.RowIndex >= 0 && e.RowIndex < dataGridView.RowCount)
            {
                //DataGridViewRow row = dataGridView.Rows[e.RowIndex];
                // 这里可以处理row的相关操作  
                if (dataGridView.Rows.Count > 0 && dataGridView.Columns.Count > 0)
                {
                    // DataGridViewCell cell = dataGridView.Rows[e.RowIndex].Cells[0];
                    // MessageBox.Show(cell.Value.ToString());
                    jilu.Text = dataGridView.Rows[e.RowIndex].Cells[0].Value.ToString();
                    yi.Text = dataGridView.Rows[e.RowIndex].Cells[1].Value.ToString();
                    er.Text = dataGridView.Rows[e.RowIndex].Cells[2].Value.ToString();
                    san.Text = dataGridView.Rows[e.RowIndex].Cells[3].Value.ToString()+"-"+ dataGridView.Rows[e.RowIndex].Cells[4].Value.ToString();
                    si.Text = dataGridView.Rows[e.RowIndex].Cells[5].Value.ToString();
                    wu.Text = dataGridView.Rows[e.RowIndex].Cells[6].Value.ToString();
                    liu.Text = dataGridView.Rows[e.RowIndex].Cells[7].Value.ToString();
                    qi.Text = dataGridView.Rows[e.RowIndex].Cells[8].Value.ToString();
                    ba.Text = dataGridView.Rows[e.RowIndex].Cells[9].Value.ToString();
                    jiu.Text = dataGridView.Rows[e.RowIndex].Cells[10].Value.ToString();
                    shi.Text = dataGridView.Rows[e.RowIndex].Cells[11].Value.ToString();
                    shiyi.Text = dataGridView.Rows[e.RowIndex].Cells[12].Value.ToString();
                    IsPaidbox.Text = dataGridView.Rows[e.RowIndex].Cells[13].Value.ToString();
                    paybybox.Text = dataGridView.Rows[e.RowIndex].Cells[14].Value.ToString();
                    marktxt.Text = dataGridView.Rows[e.RowIndex].Cells[15].Value.ToString();



                }
                else
                {
                    _ = MessageBox.Show("DataGridView中没有行或单元格");
                }

            }
            else
            {
                // 索引超出范围的错误处理  
                return;

            }



        }

        private void updatebtn_Click(object sender, EventArgs e)//更新数据到数据库并刷新界面
        {

            try
            {
                var filename = ".\\ldatabase.db";
                using (var db = new LiteDatabase(filename))
                {
                    var collection = db.GetCollection<Account>("accounts");
                    var setting = collection.FindOne(s => s.ID == int.Parse(jilu.Text));

                    if (setting != null)
                    {
                        setting.IsPaid = IsPaidbox.Text;
                        setting.payby = paybybox.Text;
                        setting.Subtotal = double.Parse(jiu.Text);
                        setting.Discount = double.Parse(shi.Text);

                        var success = collection.Update(setting);

                        if (success)
                        {
                            MessageBox.Show("更新成功***");
                            RefreshData();
                        }
                        else
                        {
                            MessageBox.Show("没有记录被更新。");
                        }
                    }
                    else
                    {
                        MessageBox.Show("没有找到指定的设置。");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            RefreshData();

        }

        private void button4_Click(object sender, EventArgs e)
        {


            // 删除数据后重新获取数据并绑定到DataGridView控件
            using (var db = new LiteDatabase(".\\ldatabase.db"))
            {
                var collection = db.GetCollection<Account>("Accounts");
                var Accountsdata = collection.FindAll().ToList();
                //清空DataGridView原有数据
                //将查询结果绑定到DataGridView
                if (dataGridView.DataSource != null)
                {
                    dataGridView.DataSource = null;
                    dataGridView.Rows.Clear();
                }
                dataGridView.DataSource = new BindingList<Account>(Accountsdata);
            }


            int hanng = 0;
            //foreach (DataGridViewRow row in dataGridView.Rows)
            //{
            //    if (row == null || row.Cells == null || row.Cells.Count <= 12)
            //    {
            //        continue; // 跳过当前迭代  
            //    }
            //    string pay = row.Cells[12].Value?.ToString();
            //    if (pay == "是")
            //    {
            //        // 这里也可以使用空条件运算符来避免null引用  
            //        row.DefaultCellStyle.BackColor = Color.GreenYellow;
            //    }
            //    else if (!string.IsNullOrEmpty(pay))
            //    {
            //        row.DefaultCellStyle.BackColor = Color.LightYellow;
            //    }
            //    hanng++;
            //}




            //if (dataTable.Rows.Count > 0)
            //{
            //    dataGridView.DataSource = dataTable;
            //    string pay = dataGridView.Rows[0].Cells[12].Value.ToString();
            //    if (pay == "是")
            //    {
            //        dataGridView.DefaultCellStyle.BackColor = Color.GreenYellow;


            //    }
            //    else
            //    {
            //        //                    dataGridView.BackgroundColor = Color.Red;
            //        dataGridView.DefaultCellStyle.BackColor = Color.LightYellow;
            //    }

            //}




            // 关闭数据库连接

            jisuan();
        }

        private void RefreshData()//刷新数据记录显示
        {
            _ = CustomerNamebox.Text;


            string customerName = CustomerNamebox.Text;
            using (var db = new LiteDatabase(".\\ldatabase.db"))
            {
                var collection = db.GetCollection<Account>("Accounts");
                //var query = collection.Query().Where(a => a.CustomerName == customerName && a.IsPaid == "是");
                var query = collection.Query().Where(a => a.CustomerName == customerName);
                var Accountsdata = query.ToList();

                //清空DataGridView原有数据

                if (dataGridView.DataSource != null)
                {
                    dataGridView.DataSource = null;
                    dataGridView.Rows.Clear();
                }
                //将查询结果绑定到DataGridView
                dataGridView.DataSource = new BindingList<Account>(Accountsdata);

            }

            DataTable dataTable = new DataTable();


            if (dataTable.Rows.Count > 0)
            {
                dataGridView.DataSource = dataTable;
                string pay = dataGridView.Rows[0].Cells[12].Value.ToString();
                if (pay == "是")
                {
                    dataGridView.DefaultCellStyle.BackColor = Color.GreenYellow;


                }
                else
                {
                    //                    dataGridView.BackgroundColor = Color.Red;
                    dataGridView.DefaultCellStyle.BackColor = Color.LightYellow;
                }

            }
 
            jisuan();
        }

        private void dataGridView_KeyDown(object sender, KeyEventArgs e)//删除选中行
        {
            if (e.KeyCode == Keys.Delete)
            {
                // 弹出提示框，询问用户是否确认删除数据
                DialogResult result = MessageBox.Show("确定要删除所有数据吗？", "确认删除", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                if (result == DialogResult.No)
                {

                    // return;

                }
                else
                {
                    // 获取选中的行  
                    DataGridViewRow selectedRow = dataGridView.SelectedRows[0];

                    // 获取需要删除的数据  
                    string recordtime = selectedRow.Cells[12].Value.ToString();
                    //dataGridView.Rows[e.RowIndex].Cells[0].Value.ToString();

                    // 创建一个连接到Access数据库的连接对象  
                    using (var db = new LiteDatabase(".\\ldatabase.db")) { 
                    
                    var collection = db.GetCollection<Account>("accounts");




                        // 删除Accounts表中符合条件的记录  
                        var documentToDelete = collection.Find(x => x.RecordTime == recordtime);
                        if (documentToDelete != null)
                        {
                            collection.DeleteMany(x => x.RecordTime == recordtime);
                            MessageBox.Show("删除成功");
                        }

                    }

                     

                    // 删除符合条件的记录  
                    //SQLiteCommand command = new SQLiteCommand("DELETE FROM Accounts WHERE AccountID = @AccountID", connection);
                    //_ = command.Parameters.AddWithValue("@AccountID", accountID);
                    //_ = command.ExecuteNonQuery();

                    
                    
                }

            }
            RefreshData();
        }

        private void jisuan()
        {
            int hanng = 0;
            double total = 0.0;
            double totalyh = 0.0;

            foreach (DataGridViewRow row in dataGridView.Rows)
            {
                if (row == null || row.Cells == null || row.Cells.Count <= 12)
                {
                    continue; // 跳过当前迭代  
                }

                string pay = row.Cells[12].Value?.ToString();
                if (pay == "是")
                {
                    row.DefaultCellStyle.BackColor = Color.GreenYellow;
                }
                else if (!string.IsNullOrEmpty(pay))
                {
                    row.DefaultCellStyle.BackColor = Color.LightYellow;
                }
                if (row.IsNewRow)
                {
                    continue;
                }


                hanng++;
                total += Convert.ToDouble(row.Cells["subtotal"].Value);
                totalyh += Convert.ToDouble(row.Cells["discount"].Value);
            }

            totalprice.Text = "当前" + hanng + "条记录，合计：" + (total - totalyh).ToString() + "元";
        }

        private void IsPaidbox_SelectedIndexChanged(object sender, EventArgs e)
        {
            paybybox.Enabled = IsPaidbox.Text != "否";
        }

        private void yi_TextChanged(object sender, EventArgs e)
        {
            if (yi.Text != "")
            {
                updatebtn.Enabled = true;

            }
        }

        private void button5_Click(object sender, EventArgs e)
        {


            // 创建一个连接到Access数据库的连接对象  
            using (var db = new LiteDatabase(".\\ldatabase.db"))
            {
                string name = CustomerNamebox.Text;
                var collection = db.GetCollection<Account>("accounts");

                // 更新特定条件的文档  
                var documentToUpdate = collection.Find(x => x.CustomerName == name).FirstOrDefault();
                if (documentToUpdate != null)
                {
                    documentToUpdate.IsPaid = "是";
                    documentToUpdate.payby = "";
                    documentToUpdate.Remark=DateTime.Now.ToString()+ "一键批量结账";
                    collection.Update(documentToUpdate);
                }
            } 
       

            //清空DataGridView原有数据
            //将查询结果绑定到DataGridView
            if (dataGridView.DataSource != null)
            {
                dataGridView.DataSource = null;
                dataGridView.Rows.Clear();
            }
            DataTable dataTable = new DataTable();
            if (dataTable.Rows.Count > 0)
            {
                dataGridView.DataSource = dataTable;
                string pay = dataGridView.Rows[0].Cells[12].Value.ToString();
                if (pay == "是")
                {
                    dataGridView.DefaultCellStyle.BackColor = Color.GreenYellow;


                }
                else
                {
                    //                    dataGridView.BackgroundColor = Color.Red;
                    dataGridView.DefaultCellStyle.BackColor = Color.LightYellow;
                }

            }

            
            jisuan();
        }
    }
}

