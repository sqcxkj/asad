﻿using LiteDB;
using System;
 
using System.Data;
using System.Data.SQLite;
using System.Drawing;
using System.IO;
using static 广告账本.SystemSettingForm;
using System.Threading;
using System.Windows.Forms;
using System.ComponentModel;
using System.Linq;

namespace 广告账本
{
    public partial class AddRecordForm : Form
    {
        public AddRecordForm()
        {
            InitializeComponent();
            //  this.Load += AddRecordForm_Load; // 添加Load事件处理程序

        }
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            CustomerNamebox = new System.Windows.Forms.ComboBox();
            label1 = new System.Windows.Forms.Label();
            ProductIDbox = new System.Windows.Forms.ComboBox();
            ProductIDlabel = new System.Windows.Forms.Label();
            label2 = new System.Windows.Forms.Label();
            Processbox = new System.Windows.Forms.ComboBox();
            label3 = new System.Windows.Forms.Label();
            Lengthtext = new System.Windows.Forms.TextBox();
            Widthtext = new System.Windows.Forms.TextBox();
            label4 = new System.Windows.Forms.Label();
            Unittext = new System.Windows.Forms.TextBox();
            label5 = new System.Windows.Forms.Label();
            UnitPricetext = new System.Windows.Forms.TextBox();
            label6 = new System.Windows.Forms.Label();
            Subtotaltext = new System.Windows.Forms.TextBox();
            label7 = new System.Windows.Forms.Label();
            Discounttext = new System.Windows.Forms.TextBox();
            label8 = new System.Windows.Forms.Label();
            label9 = new System.Windows.Forms.Label();
            dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            label10 = new System.Windows.Forms.Label();
            IsPaidbox = new System.Windows.Forms.ComboBox();
            textBox1 = new System.Windows.Forms.TextBox();
            label11 = new System.Windows.Forms.Label();
            dataGridView = new System.Windows.Forms.DataGridView();
            Addbutton = new System.Windows.Forms.Button();
            Numbertext = new System.Windows.Forms.TextBox();
            label12 = new System.Windows.Forms.Label();
            filename = new System.Windows.Forms.TextBox();
            label13 = new System.Windows.Forms.Label();
            yesadd = new System.Windows.Forms.Button();
            totalprice = new System.Windows.Forms.Label();
            label14 = new System.Windows.Forms.Label();
            button1 = new System.Windows.Forms.Button();
            danwei = new System.Windows.Forms.Label();
            danwei1 = new System.Windows.Forms.Label();
            label15 = new System.Windows.Forms.Label();
            paybybox = new System.Windows.Forms.ComboBox();
            label16 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)dataGridView).BeginInit();
            SuspendLayout();
            // 
            // CustomerNamebox
            // 
            CustomerNamebox.Anchor = System.Windows.Forms.AnchorStyles.None;
            CustomerNamebox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            CustomerNamebox.Font = new System.Drawing.Font("宋体", 12F);
            CustomerNamebox.FormattingEnabled = true;
            CustomerNamebox.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            CustomerNamebox.Location = new System.Drawing.Point(138, 33);
            CustomerNamebox.Name = "CustomerNamebox";
            CustomerNamebox.Size = new System.Drawing.Size(130, 24);
            CustomerNamebox.TabIndex = 0;
            CustomerNamebox.Text = "散客";
            CustomerNamebox.TextChanged += new System.EventHandler(CustomerNamebox_TextUpdate);
            // 
            // label1
            // 
            label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            label1.AutoSize = true;
            label1.Font = new System.Drawing.Font("宋体", 11F);
            label1.Location = new System.Drawing.Point(36, 37);
            label1.Name = "label1";
            label1.Size = new System.Drawing.Size(82, 15);
            label1.TabIndex = 1;
            label1.Text = "选择客户名";
            // 
            // ProductIDbox
            // 
            ProductIDbox.Anchor = System.Windows.Forms.AnchorStyles.None;
            ProductIDbox.Font = new System.Drawing.Font("宋体", 12F);
            ProductIDbox.FormattingEnabled = true;
            ProductIDbox.Location = new System.Drawing.Point(163, 110);
            ProductIDbox.Name = "ProductIDbox";
            ProductIDbox.Size = new System.Drawing.Size(78, 24);
            ProductIDbox.TabIndex = 2;
            ProductIDbox.SelectedIndexChanged += new System.EventHandler(ProductIDbox_SelectedValueChanged);
            ProductIDbox.TextUpdate += new System.EventHandler(ProductIDbox_SelectedValueChanged);
            ProductIDbox.TextChanged += new System.EventHandler(ProductIDbox_TextChanged);
            // 
            // ProductIDlabel
            // 
            ProductIDlabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            ProductIDlabel.AutoSize = true;
            ProductIDlabel.Font = new System.Drawing.Font("宋体", 11F);
            ProductIDlabel.Location = new System.Drawing.Point(184, 83);
            ProductIDlabel.Name = "ProductIDlabel";
            ProductIDlabel.Size = new System.Drawing.Size(37, 15);
            ProductIDlabel.TabIndex = 3;
            ProductIDlabel.Text = "类型";
            // 
            // label2
            // 
            label2.Anchor = System.Windows.Forms.AnchorStyles.None;
            label2.AutoSize = true;
            label2.Font = new System.Drawing.Font("宋体", 11F);
            label2.Location = new System.Drawing.Point(282, 83);
            label2.Name = "label2";
            label2.Size = new System.Drawing.Size(37, 15);
            label2.TabIndex = 5;
            label2.Text = "工艺";
            // 
            // Processbox
            // 
            Processbox.Anchor = System.Windows.Forms.AnchorStyles.None;
            Processbox.Font = new System.Drawing.Font("宋体", 12F);
            Processbox.FormattingEnabled = true;
            Processbox.Location = new System.Drawing.Point(250, 110);
            Processbox.Name = "Processbox";
            Processbox.Size = new System.Drawing.Size(98, 24);
            Processbox.TabIndex = 4;
            Processbox.TextChanged += new System.EventHandler(Processbox_TextChanged);
            // 
            // label3
            // 
            label3.Anchor = System.Windows.Forms.AnchorStyles.None;
            label3.AutoSize = true;
            label3.Font = new System.Drawing.Font("宋体", 11F);
            label3.Location = new System.Drawing.Point(370, 83);
            label3.Name = "label3";
            label3.Size = new System.Drawing.Size(37, 15);
            label3.TabIndex = 7;
            label3.Text = "长度";
            // 
            // Lengthtext
            // 
            Lengthtext.Anchor = System.Windows.Forms.AnchorStyles.None;
            Lengthtext.Font = new System.Drawing.Font("宋体", 12F);
            Lengthtext.Location = new System.Drawing.Point(369, 109);
            Lengthtext.Name = "Lengthtext";
            Lengthtext.Size = new System.Drawing.Size(78, 26);
            Lengthtext.TabIndex = 8;
            Lengthtext.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            Lengthtext.TextChanged += new System.EventHandler(Widthtext_TextChanged);
            Lengthtext.KeyPress += new System.Windows.Forms.KeyPressEventHandler(Lengthtext_KeyPress);
            // 
            // Widthtext
            // 
            Widthtext.Anchor = System.Windows.Forms.AnchorStyles.None;
            Widthtext.Font = new System.Drawing.Font("宋体", 12F);
            Widthtext.Location = new System.Drawing.Point(477, 109);
            Widthtext.Name = "Widthtext";
            Widthtext.Size = new System.Drawing.Size(78, 26);
            Widthtext.TabIndex = 10;
            Widthtext.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            Widthtext.TextChanged += new System.EventHandler(Widthtext_TextChanged);
            Widthtext.KeyPress += new System.Windows.Forms.KeyPressEventHandler(Widthtext_KeyPress);
            // 
            // label4
            // 
            label4.Anchor = System.Windows.Forms.AnchorStyles.None;
            label4.AutoSize = true;
            label4.Font = new System.Drawing.Font("宋体", 11F);
            label4.Location = new System.Drawing.Point(478, 83);
            label4.Name = "label4";
            label4.Size = new System.Drawing.Size(37, 15);
            label4.TabIndex = 9;
            label4.Text = "宽度";
            label4.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // Unittext
            // 
            Unittext.Anchor = System.Windows.Forms.AnchorStyles.None;
            Unittext.Font = new System.Drawing.Font("宋体", 12F);
            Unittext.Location = new System.Drawing.Point(573, 109);
            Unittext.Name = "Unittext";
            Unittext.Size = new System.Drawing.Size(44, 26);
            Unittext.TabIndex = 12;
            Unittext.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label5
            // 
            label5.Anchor = System.Windows.Forms.AnchorStyles.None;
            label5.AutoSize = true;
            label5.Font = new System.Drawing.Font("宋体", 11F);
            label5.Location = new System.Drawing.Point(577, 83);
            label5.Name = "label5";
            label5.Size = new System.Drawing.Size(37, 15);
            label5.TabIndex = 11;
            label5.Text = "单位";
            label5.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // UnitPricetext
            // 
            UnitPricetext.Anchor = System.Windows.Forms.AnchorStyles.None;
            UnitPricetext.Font = new System.Drawing.Font("宋体", 12F);
            UnitPricetext.Location = new System.Drawing.Point(624, 109);
            UnitPricetext.Name = "UnitPricetext";
            UnitPricetext.Size = new System.Drawing.Size(40, 26);
            UnitPricetext.TabIndex = 14;
            UnitPricetext.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            UnitPricetext.TextChanged += new System.EventHandler(UnitPricetext_TextChanged);
            // 
            // label6
            // 
            label6.Anchor = System.Windows.Forms.AnchorStyles.None;
            label6.AutoSize = true;
            label6.Font = new System.Drawing.Font("宋体", 11F);
            label6.Location = new System.Drawing.Point(627, 83);
            label6.Name = "label6";
            label6.Size = new System.Drawing.Size(37, 15);
            label6.TabIndex = 13;
            label6.Text = "单价";
            label6.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // Subtotaltext
            // 
            Subtotaltext.Anchor = System.Windows.Forms.AnchorStyles.None;
            Subtotaltext.Font = new System.Drawing.Font("宋体", 12F);
            Subtotaltext.Location = new System.Drawing.Point(725, 109);
            Subtotaltext.Name = "Subtotaltext";
            Subtotaltext.Size = new System.Drawing.Size(77, 26);
            Subtotaltext.TabIndex = 16;
            Subtotaltext.Text = "0";
            Subtotaltext.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label7
            // 
            label7.Anchor = System.Windows.Forms.AnchorStyles.None;
            label7.AutoSize = true;
            label7.Font = new System.Drawing.Font("宋体", 11F);
            label7.Location = new System.Drawing.Point(745, 83);
            label7.Name = "label7";
            label7.Size = new System.Drawing.Size(37, 15);
            label7.TabIndex = 15;
            label7.Text = "小计";
            label7.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // Discounttext
            // 
            Discounttext.Anchor = System.Windows.Forms.AnchorStyles.None;
            Discounttext.Font = new System.Drawing.Font("宋体", 12F);
            Discounttext.Location = new System.Drawing.Point(811, 109);
            Discounttext.Name = "Discounttext";
            Discounttext.Size = new System.Drawing.Size(47, 26);
            Discounttext.TabIndex = 18;
            Discounttext.Text = "0.00";
            Discounttext.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label8
            // 
            label8.Anchor = System.Windows.Forms.AnchorStyles.None;
            label8.AutoSize = true;
            label8.Font = new System.Drawing.Font("宋体", 11F);
            label8.Location = new System.Drawing.Point(815, 83);
            label8.Name = "label8";
            label8.Size = new System.Drawing.Size(37, 15);
            label8.TabIndex = 17;
            label8.Text = "优惠";
            label8.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label9
            // 
            label9.Anchor = System.Windows.Forms.AnchorStyles.None;
            label9.AutoSize = true;
            label9.Font = new System.Drawing.Font("宋体", 11F);
            label9.Location = new System.Drawing.Point(907, 83);
            label9.Name = "label9";
            label9.Size = new System.Drawing.Size(67, 15);
            label9.TabIndex = 19;
            label9.Text = "当前时间";
            label9.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // dateTimePicker1
            // 
            dateTimePicker1.Anchor = System.Windows.Forms.AnchorStyles.None;
            dateTimePicker1.Font = new System.Drawing.Font("宋体", 12F);
            dateTimePicker1.Location = new System.Drawing.Point(865, 109);
            dateTimePicker1.Name = "dateTimePicker1";
            dateTimePicker1.Size = new System.Drawing.Size(136, 26);
            dateTimePicker1.TabIndex = 20;
            // 
            // label10
            // 
            label10.Anchor = System.Windows.Forms.AnchorStyles.None;
            label10.AutoSize = true;
            label10.Font = new System.Drawing.Font("宋体", 11F);
            label10.Location = new System.Drawing.Point(1001, 83);
            label10.Name = "label10";
            label10.Size = new System.Drawing.Size(67, 15);
            label10.TabIndex = 21;
            label10.Text = "是否结账";
            label10.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // IsPaidbox
            // 
            IsPaidbox.Anchor = System.Windows.Forms.AnchorStyles.None;
            IsPaidbox.Font = new System.Drawing.Font("宋体", 12F);
            IsPaidbox.FormattingEnabled = true;
            IsPaidbox.Items.AddRange(new object[] {
            "否",
            "是"});
            IsPaidbox.Location = new System.Drawing.Point(1008, 110);
            IsPaidbox.Name = "IsPaidbox";
            IsPaidbox.Size = new System.Drawing.Size(51, 24);
            IsPaidbox.TabIndex = 22;
            IsPaidbox.Text = "否";
            IsPaidbox.SelectedIndexChanged += new System.EventHandler(IsPaidbox_SelectedIndexChanged);
            // 
            // textBox1
            // 
            textBox1.Anchor = System.Windows.Forms.AnchorStyles.None;
            textBox1.Font = new System.Drawing.Font("宋体", 12F);
            textBox1.Location = new System.Drawing.Point(1153, 109);
            textBox1.Name = "textBox1";
            textBox1.Size = new System.Drawing.Size(169, 26);
            textBox1.TabIndex = 24;
            textBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label11
            // 
            label11.Anchor = System.Windows.Forms.AnchorStyles.None;
            label11.AutoSize = true;
            label11.Font = new System.Drawing.Font("宋体", 11F);
            label11.Location = new System.Drawing.Point(1195, 83);
            label11.Name = "label11";
            label11.Size = new System.Drawing.Size(67, 15);
            label11.TabIndex = 23;
            label11.Text = "备注说明";
            label11.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // dataGridView
            // 
            dataGridViewCellStyle12.BackColor = System.Drawing.Color.FromArgb(192, 255, 192);
            dataGridView.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle12;
            dataGridView.Anchor = System.Windows.Forms.AnchorStyles.None;
            dataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView.GridColor = System.Drawing.SystemColors.ActiveCaptionText;
            dataGridView.Location = new System.Drawing.Point(13, 213);
            dataGridView.Name = "dataGridView";
            dataGridView.RowTemplate.Height = 23;
            dataGridView.Size = new System.Drawing.Size(1241, 312);
            dataGridView.TabIndex = 25;
            dataGridView.CellValueChanged += new System.Windows.Forms.DataGridViewCellEventHandler(dataGridView_CellValueChanged);
            dataGridView.ColumnRemoved += new System.Windows.Forms.DataGridViewColumnEventHandler(dataGridView_ColumnRemoved);
            // 
            // Addbutton
            // 
            Addbutton.BackColor = System.Drawing.Color.FromArgb(0, 192, 192);
            Addbutton.Font = new System.Drawing.Font("宋体", 12F);
            Addbutton.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            Addbutton.Location = new System.Drawing.Point(24, 157);
            Addbutton.Name = "Addbutton";
            Addbutton.Size = new System.Drawing.Size(148, 50);
            Addbutton.TabIndex = 27;
            Addbutton.Text = "加入临时列表";
            Addbutton.UseVisualStyleBackColor = false;
            Addbutton.Click += new System.EventHandler(Addbutton_Click);
            // 
            // Numbertext
            // 
            Numbertext.Anchor = System.Windows.Forms.AnchorStyles.None;
            Numbertext.Font = new System.Drawing.Font("宋体", 12F);
            Numbertext.Location = new System.Drawing.Point(670, 109);
            Numbertext.Name = "Numbertext";
            Numbertext.Size = new System.Drawing.Size(48, 26);
            Numbertext.TabIndex = 29;
            Numbertext.Text = "1";
            Numbertext.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            Numbertext.TextChanged += new System.EventHandler(Widthtext_TextChanged);
            Numbertext.KeyPress += new System.Windows.Forms.KeyPressEventHandler(Numbertext_KeyPress);
            // 
            // label12
            // 
            label12.Anchor = System.Windows.Forms.AnchorStyles.None;
            label12.AutoSize = true;
            label12.Font = new System.Drawing.Font("宋体", 11F);
            label12.Location = new System.Drawing.Point(676, 83);
            label12.Name = "label12";
            label12.Size = new System.Drawing.Size(37, 15);
            label12.TabIndex = 28;
            label12.Text = "数量";
            label12.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // filename
            // 
            filename.Anchor = System.Windows.Forms.AnchorStyles.None;
            filename.Font = new System.Drawing.Font("宋体", 12F);
            filename.Location = new System.Drawing.Point(13, 109);
            filename.Name = "filename";
            filename.Size = new System.Drawing.Size(137, 26);
            filename.TabIndex = 31;
            filename.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label13
            // 
            label13.Anchor = System.Windows.Forms.AnchorStyles.None;
            label13.AutoSize = true;
            label13.Font = new System.Drawing.Font("宋体", 11F);
            label13.Location = new System.Drawing.Point(59, 83);
            label13.Name = "label13";
            label13.Size = new System.Drawing.Size(52, 15);
            label13.TabIndex = 30;
            label13.Text = "文件名";
            // 
            // yesadd
            // 
            yesadd.Anchor = System.Windows.Forms.AnchorStyles.None;
            yesadd.BackColor = System.Drawing.Color.LimeGreen;
            yesadd.Font = new System.Drawing.Font("宋体", 12F);
            yesadd.Location = new System.Drawing.Point(1264, 213);
            yesadd.Name = "yesadd";
            yesadd.Size = new System.Drawing.Size(63, 209);
            yesadd.TabIndex = 27;
            yesadd.Text = "添\r\n加\r\n记\r\n录";
            yesadd.UseVisualStyleBackColor = false;
            yesadd.Click += new System.EventHandler(yesadd_Click);
            // 
            // totalprice
            // 
            totalprice.AutoSize = true;
            totalprice.BackColor = System.Drawing.Color.FromArgb(255, 224, 192);
            totalprice.Font = new System.Drawing.Font("微软雅黑", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 134);
            totalprice.Location = new System.Drawing.Point(983, 157);
            totalprice.Name = "totalprice";
            totalprice.Size = new System.Drawing.Size(0, 50);
            totalprice.TabIndex = 32;
            totalprice.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, 0);
            label14.ForeColor = System.Drawing.Color.Blue;
            label14.Location = new System.Drawing.Point(815, 177);
            label14.Name = "label14";
            label14.Size = new System.Drawing.Size(166, 25);
            label14.TabIndex = 33;
            label14.Text = "当前合计金额：";
            label14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // button1
            // 
            button1.Anchor = System.Windows.Forms.AnchorStyles.None;
            button1.BackColor = System.Drawing.Color.FromArgb(255, 128, 128);
            button1.Location = new System.Drawing.Point(1264, 438);
            button1.Name = "button1";
            button1.Size = new System.Drawing.Size(63, 87);
            button1.TabIndex = 34;
            button1.Text = "关闭";
            button1.UseVisualStyleBackColor = false;
            button1.Click += new System.EventHandler(button1_Click);
            // 
            // danwei
            // 
            danwei.AutoSize = true;
            danwei.Font = new System.Drawing.Font("宋体", 12F);
            danwei.ForeColor = System.Drawing.Color.FromArgb(192, 0, 0);
            danwei.Location = new System.Drawing.Point(518, 82);
            danwei.Name = "danwei";
            danwei.Size = new System.Drawing.Size(39, 16);
            danwei.TabIndex = 35;
            danwei.Text = "(cm)";
            // 
            // danwei1
            // 
            danwei1.AutoSize = true;
            danwei1.Font = new System.Drawing.Font("宋体", 12F);
            danwei1.ForeColor = System.Drawing.Color.FromArgb(192, 0, 0);
            danwei1.Location = new System.Drawing.Point(409, 82);
            danwei1.Name = "danwei1";
            danwei1.Size = new System.Drawing.Size(39, 16);
            danwei1.TabIndex = 36;
            danwei1.Text = "(cm)";
            // 
            // label15
            // 
            label15.Anchor = System.Windows.Forms.AnchorStyles.None;
            label15.AutoSize = true;
            label15.Font = new System.Drawing.Font("宋体", 11F);
            label15.Location = new System.Drawing.Point(1077, 83);
            label15.Name = "label15";
            label15.Size = new System.Drawing.Size(67, 15);
            label15.TabIndex = 37;
            label15.Text = "结账方式";
            label15.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // paybybox
            // 
            paybybox.Anchor = System.Windows.Forms.AnchorStyles.None;
            paybybox.Enabled = false;
            paybybox.Font = new System.Drawing.Font("宋体", 12F);
            paybybox.FormattingEnabled = true;
            paybybox.Items.AddRange(new object[] {
            "微信",
            "支付宝",
            "现金",
            "银联"});
            paybybox.Location = new System.Drawing.Point(1065, 110);
            paybybox.Name = "paybybox";
            paybybox.Size = new System.Drawing.Size(80, 24);
            paybybox.TabIndex = 38;
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.Location = new System.Drawing.Point(1063, 20);
            label16.Name = "label16";
            label16.Size = new System.Drawing.Size(47, 12);
            label16.TabIndex = 39;
            label16.Text = "label16";
            // 
            // AddRecordForm
            // 
            AllowDrop = true;
            AutoScroll = true;
            ClientSize = new System.Drawing.Size(1342, 556);
            Controls.Add(label16);
            Controls.Add(paybybox);
            Controls.Add(label15);
            Controls.Add(danwei1);
            Controls.Add(danwei);
            Controls.Add(button1);
            Controls.Add(label14);
            Controls.Add(totalprice);
            Controls.Add(filename);
            Controls.Add(label13);
            Controls.Add(Numbertext);
            Controls.Add(label12);
            Controls.Add(yesadd);
            Controls.Add(Addbutton);
            Controls.Add(dataGridView);
            Controls.Add(textBox1);
            Controls.Add(label11);
            Controls.Add(IsPaidbox);
            Controls.Add(label10);
            Controls.Add(dateTimePicker1);
            Controls.Add(label9);
            Controls.Add(Discounttext);
            Controls.Add(label8);
            Controls.Add(Subtotaltext);
            Controls.Add(label7);
            Controls.Add(UnitPricetext);
            Controls.Add(label6);
            Controls.Add(Unittext);
            Controls.Add(label5);
            Controls.Add(Widthtext);
            Controls.Add(label4);
            Controls.Add(Lengthtext);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(Processbox);
            Controls.Add(ProductIDlabel);
            Controls.Add(ProductIDbox);
            Controls.Add(label1);
            Controls.Add(CustomerNamebox);
            Name = "AddRecordForm";
            StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            Text = "添加记录";
            Shown += new System.EventHandler(AddRecordForm_Load);
            DragDrop += new System.Windows.Forms.DragEventHandler(AddRecordForm_DragDrop);
            DragEnter += new System.Windows.Forms.DragEventHandler(AddRecordForm_DragEnter);
            ((System.ComponentModel.ISupportInitialize)dataGridView).EndInit();
            ResumeLayout(false);
            PerformLayout();

        }

        private const string connString = "Data Source=.\\Database.db;Version=3;";
        private void ProductIDbox_SelectedValueChanged(object sender, EventArgs e)
        {
            // 建立连接
            using (SQLiteConnection conn = new SQLiteConnection(connString))
            {
                conn.Open();
                try
                {
                    // 获取选中的产品类型
                    string productType = ProductIDbox.Text;

                    // 查询符合条件的数据
                    string sql = "SELECT Process FROM ProductPrices WHERE ProductType='" + productType + "'";
                    SQLiteCommand cmd = new SQLiteCommand(sql, conn);
                    SQLiteDataReader readera = cmd.ExecuteReader();
                    DataTable dt = new DataTable();
                    dt.Load(readera);

                    // 填充下拉框
                    Processbox.DataSource = dt;
                    Processbox.DisplayMember = "Process";
                    Processbox.ValueMember = "Process";

                    // 查询符合条件的数据
                    string unsql = "SELECT Unit FROM ProductPrices WHERE ProductType='" + productType + "'";
                    cmd = new SQLiteCommand(unsql, conn);
                    SQLiteDataReader reader = cmd.ExecuteReader();

                    // 将结果显示到文本框
                    while (reader.Read())
                    {
                        string unit = reader.GetValue(0).ToString();
                        Unittext.Text = unit;
                        break; // 只需要第一行数据
                    }

                }
                catch (Exception ex)
                {
                    _ = MessageBox.Show("查询出错：" + ex.Message);
                }
                finally
                {
                    conn.Close();
                }
                conn.Close();
            }
        }
        private void yesadd_Click(object sender, EventArgs e)//添加记录到数据库
        {
            string bt = Text;
         
               
                Text = "添加记录  【后台正在进行操作】请稍等-->";
             
                if (dataGridView.Rows.Count == 0)
                {
                    _ = MessageBox.Show("数据为空");
                                        return;
                }

            // 创建一个连接到Access数据库的连接对象  
            using (var db = new LiteDatabase(".\\ldatabase.db"))
            {

                // 创建集合（类似于SQL中的表）  
                var collection = db.GetCollection<Account>("Accounts");

         

                
                    for (int i = 0; i < dataGridView.Rows.Count - 1; i++)
                    {
                        DataGridViewRow row = dataGridView.Rows[i];
                        // 获取DataGridView中每列的值
                        string guestname = row.Cells["客户名"].Value.ToString();
                        string fileName = row.Cells["文件名"].Value?.ToString() ?? "";
                        string ProductType = row.Cells["类型"].Value.ToString();
                        string process = row.Cells["工艺"].Value?.ToString() ?? "";
                        _ = double.TryParse(row.Cells["长度"].Value?.ToString(), out double length);
                        _ = double.TryParse(row.Cells["宽度"].Value?.ToString(), out double width);
                        _ = double.TryParse(row.Cells["单价"].Value?.ToString(), out double unitPrice);
                        _ = int.TryParse(row.Cells["数量"].Value?.ToString(), out int quantity);
                        _ = double.TryParse(row.Cells["小计"].Value?.ToString(), out double subtotal);
                        _ = double.TryParse(row.Cells["优惠"].Value?.ToString(), out double discount);
                        string unit = row.Cells["单位"].Value.ToString();
                        string datime = row.Cells["时间"].Value.ToString();
                        string isPaid = row.Cells["是否结账"].Value.ToString();
                        string payby = row.Cells["结账方式"].Value.ToString();
                        string remark = row.Cells["备注"].Value?.ToString() ?? "";
                        // 创建一个触发器，当插入记录时触发
                        // 定义一个文档对象  
                        var doc = new Account
                        {
                            CustomerName = guestname,
                            Filename=fileName,
                            ProductType=ProductType,
                            Process=process,
                            Length=length,
                            Width=width,
                            Unit=unit,
                            UnitPrice=unitPrice,
                            cpNumber=quantity,
                            Subtotal=subtotal,
                            Discount=discount,
                            RecordTime=datime,
                            IsPaid=isPaid,
                            payby=payby,
                            Remark=remark,


                        };
                        MessageBox.Show("添加成功");

                        // 将文档插入集合  
                        collection.Insert(doc);

                    }

                    _ = MessageBox.Show("记录添加成功！");
                    // 清除dataGridView数据
                    Text = bt;
                    dataGridView.DataSource = null;
                    dataGridView.Rows.Clear();
                    dataGridView.Columns.Clear();
              



            }




        }


        private void Addbutton_Click(object sender, EventArgs e)   //添加到临时列表
        {  //增加临时记录
            // 获取用户输入的信息
            string guestname = CustomerNamebox.Text;
            string fileName = filename.Text;
            string type = ProductIDbox.Text;
            string process = Processbox.Text;
            string length = Lengthtext.Text;
            string width = Widthtext.Text;
            string unit = Unittext.Text;
            string unitPrice = UnitPricetext.Text;
            string quantity = Numbertext.Text;
            string subtotal = Subtotaltext.Text;
            string discount = Discounttext.Text;
            DateTime time = dateTimePicker1.Value;
            string isPaid = IsPaidbox.Text;
            string payby = paybybox.Text;
            string remark = textBox1.Text;

            // 如果DataGridView中没有列，则先创建列
            if (dataGridView.Columns.Count == 0)
            {
                // 创建DataGridView列
                _ = dataGridView.Columns.Add("序号", "序号");
                _ = dataGridView.Columns.Add("客户名", "客户名");
                _ = dataGridView.Columns.Add("文件名", "文件名");
                _ = dataGridView.Columns.Add("类型", "类型");
                _ = dataGridView.Columns.Add("工艺", "工艺");
                _ = dataGridView.Columns.Add("长度", "长度");
                _ = dataGridView.Columns.Add("宽度", "宽度");
                _ = dataGridView.Columns.Add("单位", "单位");
                _ = dataGridView.Columns.Add("单价", "单价");
                _ = dataGridView.Columns.Add("数量", "数量");
                _ = dataGridView.Columns.Add("小计", "小计");
                _ = dataGridView.Columns.Add("优惠", "优惠");
                _ = dataGridView.Columns.Add("时间", "时间");
                _ = dataGridView.Columns.Add("是否结账", "是否结账");
                _ = dataGridView.Columns.Add("结账方式", "结账方式");
                _ = dataGridView.Columns.Add("备注", "备注");
            }
            // 添加记录到DataGridView中
            int index = dataGridView.Rows.Count;
            object[] row = new object[]
            {
        index,
        guestname,
        fileName,
        type,
        process,
        length,
        width,
        unit,
        unitPrice,
        quantity,
        subtotal,
        discount,
        time,
        isPaid,
        payby,
        remark
            };
            _ = dataGridView.Rows.Add(row);

            // 获取DataGridView中每列的值
            double total = 0;
            // foreach (DataGridViewRow row in this.dataGridView.Rows)
            for (int i = 0; i < dataGridView.Rows.Count - 1; i++)
            {
                DataGridViewRow rowa = dataGridView.Rows[i];

                {
                    _ = double.TryParse(rowa.Cells["小计"].Value.ToString(), out double subtotalVal);
                    total += subtotalVal;
                }
            }
            totalprice.Text = total.ToString() + "元";


            // 自动调整列宽


            dataGridView.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dataGridView.AutoResizeColumns();
            // 获取容器控件中的所有文本框，并将它们的 Text 属性设置为空字符串

            Lengthtext.Text = "0";
            Widthtext.Text = "0";
            Numbertext.Text = "1";
            Subtotaltext.Text = "0"; ;
            Discounttext.Text = "0";
            filename.Text = "";
            IsPaidbox.Text = "否";


        }

        private void AddRecordForm_Load(object sender, EventArgs e)//载入页面代码
        {           

            // 使用 LiteDatabase 类创建一个新的数据库连接实例，连接到一个名为 ldatabase.db 的文件数据库  
            // 数据库的连接被封装在一个 using 语句块中，这意味着在代码执行完毕后，数据库连接将会被自动关闭  
            using (var db = new LiteDatabase(".\\ldatabase.db"))
            {
                // 通过数据库连接获取一个名为 "Customer" 的集合（类似于传统数据库中的表）  
                // LiteDatabase 使用 BsonDocument 作为集合中的文档类型  
                var namelist = db.GetCollection<BsonDocument>("Customers");

              
                // 其他属性...则被设置为原文档的其他字段的值（具体哪些字段取决于 Customer 类的定义）  
                var namelb = namelist.FindAll()
                    .Select(doc => new Customer
                    {
                        CustomerName = doc["CustomerName"].AsString,  //从集合DOC中获取相应字段的值    
                                                                    
                    })
                    .ToList();

                // 将得到的 Customer 对象列表赋值给 CustomerNamebox 的 DataSource 属性  
                // 这意味着 CustomerNamebox 将展示这个列表中的所有 Customer 对象  
                CustomerNamebox.DataSource = new BindingList<Customer>(namelb);

                // 设置 CustomerNamebox 的 DisplayMember 属性为 "CustomerName"  
                // 这意味着在 CustomerNamebox 中将显示每个 Customer 对象的 CustomerName 属性的值，而不是显示整个 Customer 对象  
                CustomerNamebox.DisplayMember = "CustomerName"; // 设置在列表中显示的成员    
                                                                //  producttype.ValueMember = "_id"; // 设置作为实际值的成员    

            }



            //string connectionString = "Data Source=.\\Database.db;Version=3;";
            //using (SQLiteConnection conn = new SQLiteConnection(connectionString))
            //{
            //    conn.Open();
            //    try
            //    {

            //        // 查询客户名称
            //        string sql = "SELECT CustomerName FROM Customers";
            //        SQLiteCommand cmd = new SQLiteCommand(sql, conn);
            //        SQLiteDataReader reader = cmd.ExecuteReader();
            //        DataTable dt = new DataTable();
            //        dt.Load(reader);

            //        // 填充下拉框
            //        CustomerNamebox.DataSource = dt;
            //        CustomerNamebox.DisplayMember = "CustomerName";
            //        CustomerNamebox.ValueMember = "CustomerName";

            //        // 查询类型名称
            //        string sql1 = "SELECT ProductType FROM CpType";
            //        SQLiteCommand cmd1 = new SQLiteCommand(sql1, conn);
            //        SQLiteDataReader reader1 = cmd1.ExecuteReader();
            //        DataTable dt1 = new DataTable();
            //        dt1.Load(reader1);

            //        // 填充下拉框
            //        ProductIDbox.DataSource = dt1;
            //        ProductIDbox.DisplayMember = "ProductType";
            //        ProductIDbox.ValueMember = "ProductType";

            //        // 查询工艺名称
            //        string sql2 = "SELECT Process FROM ProductPrices";
            //        SQLiteCommand cmd2 = new SQLiteCommand(sql2, conn);
            //        SQLiteDataReader reader2 = cmd2.ExecuteReader();
            //        DataTable dt2 = new DataTable();
            //        dt2.Load(reader2);

            //        // 填充下拉框
            //        Processbox.DataSource = dt2;
            //        Processbox.DisplayMember = "Process";
            //        Processbox.ValueMember = "Process";

            //        // 获取选中的产品类型
            //        string productType = ProductIDbox.Text;

            //        // 查询符合条件的数据
            //        string sql3 = "SELECT Process FROM ProductPrices WHERE ProductType='" + productType + "'";
            //        SQLiteCommand cmd3 = new SQLiteCommand(sql3, conn);
            //        SQLiteDataReader reader3 = cmd3.ExecuteReader();
            //        DataTable dt3 = new DataTable();
            //        dt3.Load(reader3);

            //        // 填充下拉框
            //        Processbox.DataSource = dt3;
            //        Processbox.DisplayMember = "Process";
            //        Processbox.ValueMember = "Process";

            //        conn.Close();
            //    }
            //    catch (Exception)
            //    {
            //        _ = MessageBox.Show("数据库未打开");
            //    }
            //    conn.Close();
            //}

        }




        private void ProductIDbox_TextChanged(object sender, EventArgs e)
        {
            // 更改单价文本框的值
            UnitPricetext.Text = GetUnitPrice(ProductIDbox.Text.Trim(), Processbox.Text.Trim());
        }

        private void Processbox_TextChanged(object sender, EventArgs e)
        {
            // 其他操作...

            // 更改单价文本框的值
            UnitPricetext.Text = GetUnitPrice(ProductIDbox.Text.Trim(), Processbox.Text.Trim());
        }

        // 从数据库中获取指定产品类型和工艺的单价
        private string GetUnitPrice(string productType, string process)
        {// 建立连接
            using (SQLiteConnection connection = new SQLiteConnection(connString))
            {
                connection.Open();

                string customerName = CustomerNamebox.Text;
                int customerLevel = 1;
                string sql = "SELECT customerLevel FROM customers WHERE customerName = @customerName";
                using (SQLiteCommand command = new SQLiteCommand(sql, connection))
                {
                    _ = command.Parameters.AddWithValue("@customerName", customerName);
                    customerLevel = Convert.ToInt32(command.ExecuteScalar());
                }

                string unitPriceColumn;
                switch (customerLevel)
                {
                    case 1:
                        unitPriceColumn = "unitprice";
                        break;
                    case 2:
                        unitPriceColumn = "unitprice";
                        break;
                    case 3:
                        unitPriceColumn = "unitprice";
                        break;
                    default:
                        unitPriceColumn = "unitprice"; // 默认等级为1
                        break;
                }

                // 关闭数据库连接
                connection.Close();

                sql = $"SELECT {unitPriceColumn} FROM ProductPrices WHERE ProductType=@productType AND Process=@process";
                using (SQLiteCommand command = new SQLiteCommand(sql, connection))
                { // 关闭数据库连接
                    connection.Open();
                    _ = command.Parameters.AddWithValue("@productType", productType);
                    _ = command.Parameters.AddWithValue("@process", process);
                    string unitPrice = command.ExecuteScalar()?.ToString();

                    // 判断 unitPrice 是否为空或为零，如果是，则使用 unitprice 作为默认值  
                    if (string.IsNullOrEmpty(unitPrice) || int.Parse(unitPrice) <= 0)
                    {
                        unitPrice = "0"; // 使用默认值 unitprice  
                    }
                    // 关闭数据库连接
                    connection.Close();
                    return unitPrice ?? "";
                }
            }
        }

        private void Control_TextChanged(object sender, EventArgs e)//文本框内容改变的时候计算结果
        {


            string cpleixing = ProductIDbox.Text.Trim();
            string cpgongyi = Processbox.Text.Trim();
            string youhui = Discounttext.Text.Trim() != "" ? Discounttext.Text.Trim() : "0";

            // 如果没有选择产品类型、工艺或者数量不是正数，则不进行计算
            if (string.IsNullOrEmpty(cpleixing) || string.IsNullOrEmpty(cpgongyi)
                || !double.TryParse(Numbertext.Text, out double quantity) || quantity <= 0)
            {
                Subtotaltext.Text = "0";

                return;
            }

            // 连接到数据库
            using (SQLiteConnection connection = new SQLiteConnection(connString))
            {
                connection.Open();

                // 查询类型名称
                string sql = "SELECT jijiafangshi FROM CpType WHERE producttype=@producttype";
                SQLiteCommand cmd = new SQLiteCommand(sql, connection);
                _ = cmd.Parameters.AddWithValue("@producttype", cpleixing);
                SQLiteDataReader readerFS = cmd.ExecuteReader();
                string unitType = "";
                if (readerFS.Read())
                {
                    // 直接赋值
                    unitType = readerFS["jijiafangshi"].ToString();
                }
                else
                {
                   
                }

                {

                    // 从数据库中检索计算公式和单价
                    SQLiteCommand command1 = new SQLiteCommand("SELECT CalculationFormula FROM systemsettings WHERE jijiafangshi=?", connection);
                    _ = command1.Parameters.AddWithValue("jijiafangshi", unitType); // 为参数指定值

                    string CalculationFormula = command1.ExecuteScalar()?.ToString();

                    // 从数据库中检索最低价和单位
                    SQLiteCommand command2 = new SQLiteCommand("SELECT lowprice, lwunit FROM ProductPrices WHERE ProductType=? AND Process=?", connection);
                    _ = command2.Parameters.AddWithValue("@ProductType", cpleixing); // 为参数指定值
                    _ = command2.Parameters.AddWithValue("@Process", cpgongyi); // 为参数指定值
                    string lwunit = "";
                    int zuidijia = 0;
                    using (SQLiteDataReader reader = command2.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            // 检查 "lwunit" 字段是否包含 DBNull 值
                            if (reader.IsDBNull(reader.GetOrdinal("lwunit")))
                            {
                                // 如果包含 DBNull 值，则设置默认值或跳过该行数据的处理
                                lwunit = "default value";
                            }
                            else
                            {
                                // 如果不包含 DBNull 值，则正常处理该行数据
                                lwunit = Convert.ToString(reader["lwunit"]);
                                danwei.Text = lwunit;
                                danwei1.Text = lwunit;
                            }

                            // 检查 "lowprice" 字段是否包含 DBNull 值
                            if (reader.IsDBNull(reader.GetOrdinal("lowprice")))
                            {
                                // 如果包含 DBNull 值，则设置默认值或跳过该行数据的处理
                                zuidijia = 0;
                            }
                            else
                            {
                                // 如果不包含 DBNull 值，则正常处理该行数据
                                zuidijia = Convert.ToInt32(reader["lowprice"]);
                            }
                        }

                        if (CalculationFormula != null && decimal.TryParse(UnitPricetext.Text, out decimal unitPrice))
                        {
                            // 解析输入的参数
                            _ = decimal.TryParse(Lengthtext.Text, out decimal length);
                            _ = decimal.TryParse(Widthtext.Text, out decimal width);



                            if (lwunit == "厘米" || lwunit == "cm")
                            {
                                length /= 100;
                                width /= 100;
                            }
                            else if (lwunit == "米" || lwunit == "M")
                            {
                                length /= 1;
                                width /= 1;
                            }
                            decimal da = Math.Max(length, width);
                            decimal xiao = Math.Min(length, width);
                            length = da;
                            width = xiao;

                            // 替换占位符
                            CalculationFormula = CalculationFormula.Replace("长", length.ToString()).Replace("宽", width.ToString()).Replace("数量", quantity.ToString()).Replace("单价", unitPrice.ToString()) + "-" + youhui;

                            try
                            {
                                decimal result = new DataTable().Compute(CalculationFormula, null) as decimal? ?? 0;
                                decimal subtotal = Math.Max(result, zuidijia);//取两个数之间的最低价
                                Subtotaltext.Text = subtotal.ToString("F2");//保留两位小数
                                label16.Text = unitType + CalculationFormula + "" + result;
                            }
                            catch (Exception ex)
                            {
                                Subtotaltext.Text = "计算错误：" + ex.Message;
                                _ = MessageBox.Show(ex.Message);
                            }
                        }
                    }
                    // 关闭数据库连接
                    connection.Close();
                }


            }



        }



        private void AddRecordForm_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.FileDrop))
            {
                string[] files = (string[])e.Data.GetData(DataFormats.FileDrop);
                e.Effect = IsImageFile(files) ? DragDropEffects.Copy : DragDropEffects.None;
            }
            else
            {
                e.Effect = DragDropEffects.None;
            }
        }

        private void AddRecordForm_DragDrop(object sender, DragEventArgs e)
        {

            // 获取拖拽的文件名
            string[] fileNames = (string[])e.Data.GetData(DataFormats.FileDrop);
            _ = fileNames[0];

             
            // 判断拖拽的数据是否为图像文件
            if (e.Data.GetDataPresent(DataFormats.FileDrop) && IsImageFile((string[])e.Data.GetData(DataFormats.FileDrop)))
            {
                string[] files = (string[])e.Data.GetData(DataFormats.FileDrop);
                foreach (string file in files)
                {
                    string fileName = Path.GetFileNameWithoutExtension(file);

                    filename.Text = fileName;
                    // 加载图像并获取实际尺寸
                    using (Image image = Image.FromFile(file))
                    {
                        int width = image.Width;
                        int height = image.Height;

                        // 获取图像分辨率
                        float dpiX = image.HorizontalResolution;
                        float dpiY = image.VerticalResolution;

                        // 将实际尺寸从像素转换为厘米并四舍五入到整数
                        int widthCm = (int)Math.Round(width / dpiX * 2.54f);
                        int heightCm = (int)Math.Round(height / dpiY * 2.54f);

                        // 更新界面控件
                        Lengthtext.Text = widthCm.ToString();
                        Widthtext.Text = heightCm.ToString();


                    }
                }
            }
        }




        private bool IsImageFile(string[] filePaths)
        {
            foreach (string filePath in filePaths)
            {
                string extension = Path.GetExtension(filePath).ToLower();
                if (extension == ".jpg" || extension == ".jpeg" || extension == ".png" || extension == ".bmp")
                {
                    return true;
                }
            }
            return false;
        }


        private void dataGridView_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            // 获取DataGridView中每列的值

            double total = 0;
            // foreach (DataGridViewRow row in this.dataGridView.Rows)
            for (int i = 0; i < dataGridView.Rows.Count - 1; i++)
            {
                DataGridViewRow rowa = dataGridView.Rows[i];
                //if (!row.IsNewRow && row.Cells[0].Value != null) // 忽略新行和空行
                {
                    total += Convert.ToDouble(rowa.Cells["小计"].Value);
                }
            }
            totalprice.Text = total.ToString() + "元";

        }

        private void dataGridView_ColumnRemoved(object sender, DataGridViewColumnEventArgs e)
        {
            double total = 0.0;

            for (int i = 0; i < dataGridView.Rows.Count - 1; i++)
            {
                DataGridViewRow rowa = dataGridView.Rows[i];

                {
                    total += Convert.ToDouble(rowa.Cells["小计"].Value);
                }
            }
            totalprice.Text = total.ToString() + "元";
        }

        private void Lengthtext_KeyPress(object sender, KeyPressEventArgs e)
        {
            NumericTextBox_KeyPress(sender, e);
        }//键盘事件控制

        private void Widthtext_KeyPress(object sender, KeyPressEventArgs e)
        {
            NumericTextBox_KeyPress(sender, e);
        }//键盘事件控制

        private void Numbertext_KeyPress(object sender, KeyPressEventArgs e)
        {
            NumericTextBox_KeyPress(sender, e);
        }//键盘事件控制

        private void NumericTextBox_KeyPress(object sender, KeyPressEventArgs e)  //键盘事件控制
        {
            // 如果输入的字符不是数字、删除键或小数点，则标记事件为已处理并返回  
            if (!char.IsDigit(e.KeyChar) && e.KeyChar != (char)Keys.Back && e.KeyChar != '.')
            {
                e.Handled = true;
                return;
            }

            if (!(sender is TextBox textbox))
            {
                return; // Just in case  
            }

            //// 如果文本框的内容为 "0" 并且将要输入的字符不是 '0'，那么直接用输入的字符替换 "0"  
            if (textbox.Text == "0" && e.KeyChar != '0')
            {
                textbox.Text = e.KeyChar.ToString();
                textbox.SelectionStart = 1;
                e.Handled = true;
                return;
            }

            // 如果已经有一个小数点，并且接下来要输入的也是小数点，那么标记事件为已处理并返回  
            if (e.KeyChar == '.' && textbox.Text.IndexOf(".") != -1)
            {
                e.Handled = true;
                return;
            }

        }

        private void button1_Click(object sender, EventArgs e)//关闭按钮
        {
            Close();
        }



        private void CustomerNamebox_TextUpdate(object sender, EventArgs e)//客户名称更新事件
        {

            // 建立连接
            string connectionString = "Data Source=.\\Database.db;Version=3;";
            using (SQLiteConnection conn = new SQLiteConnection(connectionString))
            {
                // 打开SQLite数据库连接
                conn.Open();

                try
                {
                    // 获取选中的产品类型
                    string productType = ProductIDbox.Text;

                    // 查询符合条件的数据
                    string sql = "SELECT Process FROM ProductPrices WHERE ProductType='" + productType + "'";
                    using (SQLiteCommand cmd = new SQLiteCommand(sql, conn))
                    {
                        using (SQLiteDataReader reader = cmd.ExecuteReader())
                        {
                            DataTable dt = new DataTable();
                            dt.Load(reader);

                            // 填充下拉框
                            Processbox.DataSource = dt;
                            Processbox.DisplayMember = "Process";
                            Processbox.ValueMember = "Process";

                        }
                    }
                }
                catch (Exception ex)
                {
                    _ = MessageBox.Show("查询出错：" + ex.Message);
                }

            }

             

        }


        private void IsPaidbox_SelectedIndexChanged(object sender, EventArgs e)//付款方式状态变更
        {
            paybybox.Enabled = IsPaidbox.Text != "否";
        }

        private void UnitPricetext_TextChanged(object sender, EventArgs e)
        {
            Control_TextChanged(sender, e);
        }

        private void Widthtext_TextChanged(object sender, EventArgs e)
        {
            Control_TextChanged(sender, e);//计算价格
        }
    }
}
