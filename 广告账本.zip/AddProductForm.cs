﻿using LiteDB;
using System;
 
using System.ComponentModel;
using System.Data;
using System.Data.SQLite;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Threading;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using static 广告账本.SystemSettingForm;

namespace 广告账本
{
    public partial class AddProductForm : Form
    {

      



        public AddProductForm()
        {
            InitializeComponent();


        }


       
        private class ProductPrice
        {
            public int _id { get; set; }
            public string ProductType { get; set; }
            public string process { get; set; }
            public double UnitPrice { get; set; }
            public double UnitPricet { get; set; }
            public double UnitPrices { get; set; }
            public string Unit { get; set; }
            public double lowprice { get; set; }
            public string JijiaFangshi { get; set; }
            public string lwunit { get; set; }

        }
        public class CpType
        {
            public int _id { get; set; }
            public string ProductType { get; set; }
            public string Unit { get; set; }
            public string JijiaFangshi { get; set; }


        }

        private void AddProductForm_Load(object sender, EventArgs e)
        {
            jilu.Text = "";
            RefreshData();


            using(var db= new LiteDatabase(".\\ldatabase.db"))
            {
                //    // 获取ProductPrices集合  
                var productjihe = db.GetCollection<BsonDocument>("Cptype");

                // 获取集合productjihe中的数据并转换为CpType对象列表  
                var typelist =productjihe.FindAll()
                    .Select(doc=> new CpType
                    {
                        //_id = doc["_id"].AsInt32,
                        ProductType = doc["ProductType"].AsString,  //从集合DOC中获取相应字段的值
                       // Unit = doc["Unit"].AsString,
                       // JijiaFangshi = doc["JijiaFangshi"].AsString
                        }
                    
                    )
                    .ToList();
                 
                // 绑定 ComboBox 控件  
                producttype.DataSource = new BindingList<CpType>(typelist);
                 producttype.DisplayMember = "ProductType"; // 设置在列表中显示的成员  
              //  producttype.ValueMember = "_id"; // 设置作为实际值的成员  

            }

             
        }



        private void dataGridView_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {

            if (e.RowIndex >= 0 && e.RowIndex < dataGridView.RowCount)
            {
                //DataGridViewRow row = dataGridView.Rows[e.RowIndex];
                // 这里可以处理row的相关操作  
                if (dataGridView.Rows.Count > 0 && dataGridView.Columns.Count > 0)
                {
                    // DataGridViewCell cell = dataGridView.Rows[e.RowIndex].Cells[0];
                    // MessageBox.Show(cell.Value.ToString());
                    jilu.Text = dataGridView.Rows[e.RowIndex].Cells[0].Value.ToString();
                    producttype.Text = dataGridView.Rows[e.RowIndex].Cells[1].Value.ToString();
                    Process.Text = dataGridView.Rows[e.RowIndex].Cells[2].Value.ToString();
                    unitprice.Text = dataGridView.Rows[e.RowIndex].Cells[3].Value.ToString();
                    unitprices.Text = dataGridView.Rows[e.RowIndex].Cells[4].Value.ToString();
                    unitpricet.Text = dataGridView.Rows[e.RowIndex].Cells[5].Value.ToString();
                    Unit.Text = dataGridView.Rows[e.RowIndex].Cells[6].Value.ToString();
                    lowprice.Text = dataGridView.Rows[e.RowIndex].Cells[7].Value.ToString();
                    Jijiafangshi.Text = dataGridView.Rows[e.RowIndex].Cells[8].Value.ToString();
                    lwunit.Text = dataGridView.Rows[e.RowIndex].Cells[9].Value.ToString();


                }
                else
                {
                    _ = MessageBox.Show("数据为空");
                }

            }
            else
            {
                // 索引超出范围的错误处理  
                return;

            }

            anniuwenzi();

        }




        private void anniuwenzi()
        {

            if (jilu.Text != "")
            {
                insbtn.Text = "提交更新";
                insbtn.BackColor = Color.LightPink;
                //RefreshData();
            }
            else
            {
                insbtn.Text = "确认添加";
                insbtn.BackColor = Color.LightGreen;
                //  RefreshData();
            }

        }


        private void insbtn_Click(object sender, EventArgs e)//点击按钮
        {
            string tishi = Text;
            Text = tishi + "   【正在执行中】，请稍等>";

            if (jilu.Text != null && jilu.Text != "")
            {
                gx();
            }
            else
            {
                tj();
            }
            //progressForm.Close();
            Text = tishi;
            anniuwenzi();


        }

        private void gx()
        {
            int cpid = int.Parse(jilu.Text);
            string cplx = producttype.Text;
            string cpgy = Process.Text;
            double cpdj = int.Parse(unitprice.Text);
            double cpdjt = int.Parse( unitpricet.Text);
            double cpdjs = int.Parse(unitprices.Text);
            string cpdw = Unit.Text;
            double cpzdj = int.Parse(lowprice.Text);
            string cplwdw = lwunit.Text;
            string cpjjfs = Jijiafangshi.Text;
                  
                if (producttype.Text == "" || Process.Text == "")
                {
                    _ = MessageBox.Show("名称或类型不能为空");
                    return;
                }                 
                    try
                    {
                //更新数据代码
                var filename = ".\\ldatabase.db";
                using (var db = new LiteDatabase(filename))
                {                    var collection = db.GetCollection<ProductPrice>("ProductPrices");
                    var settingupdate = collection.FindOne(s => s._id == cpid);
                    if (settingupdate != null)
                    {
                         
                        settingupdate.ProductType = cplx;
                        settingupdate.process = cpgy;
                        settingupdate.UnitPrice = cpdj;
                        settingupdate.UnitPricet = cpdjt;
                        settingupdate.UnitPrices = cpdjs;
                        settingupdate.Unit = cpdw;
                        settingupdate.lowprice= cpzdj;
                        settingupdate.lwunit= cplwdw;
                        settingupdate.JijiaFangshi = cpjjfs;
                        var success = collection.Update(settingupdate);

                        if (success)
                        {
                            MessageBox.Show("更新成功***");
                        }
                        else
                        {
                            MessageBox.Show("没有记录被更新。");
                        }
                    }
                    else
                    {
                        MessageBox.Show("没有找到指定的设置。");
                    }
                }



            }
            
                    catch (SQLiteException ex)
                    {
                        // 处理其他数据库异常错误
                        Text = "数据库操作错误：" + ex.Message;
                       // break;
                    }                            
      

            RefreshData();
          
        }
        private void tj()
        {
            string cplx = producttype.Text;
            string cpgy = Process.Text;
            double cpdj = double.Parse(unitprice.Text);
            double cpdjt = double.Parse(unitpricet.Text);
            double cpdjs = int.Parse(unitprices.Text);
            string cpdw = Unit.Text;
            double cpzdj = int.Parse(lowprice.Text);
            string cplwdw = lwunit.Text;
            string cpjjfs = Jijiafangshi.Text;

             

            
                if (producttype.Text == "" || Process.Text == "")
                {
                    _ = MessageBox.Show("名称或类型不能为空");
                    return;
                }

               
                    try
                    {

                //插入数据代码
                var filename = ".\\ldatabase.db";//建立数据库链接
                using (var dba = new LiteDatabase(filename))
                {
                    
                    var collection = dba.GetCollection<ProductPrice>("ProductPrices");
                    var ProductPricesadd = new ProductPrice
                    {
                        // _id = 1,
                        ProductType = cplx,
                        process = cpgy,
                        UnitPrice = cpdj,
                        UnitPricet = cpdjt,
                        UnitPrices=cpdjs,
                        Unit=cpdw,
                        lowprice=cpzdj,
                        JijiaFangshi=cpjjfs,
                        lwunit=cplwdw

                    };
                    // 插入新的CpType对象到集合中    
                    collection.Insert(ProductPricesadd);
                    MessageBox.Show("OK");
                }

            }
                  
                    catch (SQLiteException ex)
                    {
                        Text = "数据库操作错误：" + ex.Message;
                         
                    }
            

             
            RefreshData();
       
        }




        //private void dataGridView_KeyDown(object sender, KeyEventArgs e)
        //{
        //    if (e.KeyCode == Keys.Delete)
        //    {
        //        if (dataGridView.SelectedRows.Count > 0) // 检查是否有选中的行  
        //        {
        //            // 弹出提示框，询问用户是否确认删除数据  
        //            DialogResult result = MessageBox.Show("确定要删除所有数据吗？", "确认删除", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

        //            if (result == DialogResult.Yes)
        //            {
        //                foreach (DataGridViewRow selectedRow in dataGridView.SelectedRows)
        //                {
        //                    string productID = selectedRow.Cells[0].Value.ToString();

        //                    using (var db = new LiteDatabase(".\\ldatabase.db"))
        //                    {
        //                        var collection = db.GetCollection<ProductPrice>("ProductPrices");

        //                        bool deleteSuccessful = collection.Delete(productID);

        //                        if (deleteSuccessful)
        //                        {
        //                            MessageBox.Show("操作成功！");
        //                        }
        //                        else
        //                        {
        //                            MessageBox.Show("操作失败！请重试……");
        //                        }
        //                    }
        //                }

        //                RefreshData();
        //            }
        //        }
        //    }
        //}

        private void dataGridView_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Delete)
            {
                using (var db = new LiteDatabase(".\\ldatabase.db"))
                {
                    

                    if (dataGridView.SelectedRows.Count > 0) // 检查是否有选中的行  
                    {
                        // 弹出提示框，询问用户是否确认删除数据  
                        DialogResult result = MessageBox.Show("确定要删除所有数据吗？", "确认删除", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                        if (result == DialogResult.Yes)
                        {
                            var collection = db.GetCollection<ProductPrice>("ProductPrices");
                            DataGridViewRow selectedRow = dataGridView.SelectedRows[0];
                            string productID = selectedRow.Cells[0].Value.ToString();
                            MessageBox.Show(productID);
                            int id = int.Parse(productID);
                            collection.Delete(id);
                                 db.Commit();
                            MessageBox.Show("删除记录成功");
                           // RefreshData();
                        }
                    }

                    // 删除数据后重新获取数据并绑定到DataGridView控件  
                    var collectionb = db.GetCollection<ProductPrice>("ProductPrices");
                    var ProductPricedata = collectionb.FindAll().ToList();
                    dataGridView.DataSource = new BindingList<ProductPrice>(ProductPricedata);
                }
            }
            //// 删除数据后重新获取数据并绑定到DataGridView控件
            //using (var db = new LiteDatabase(".\\ldatabase.db"))
            //{
            //    var collection = db.GetCollection<ProductPrice>("ProductPrices");
            //    var ProductPricedata = collection.FindAll().ToList();
            //    dataGridView.DataSource = new BindingList<ProductPrice>(ProductPricedata);
            //}
            RefreshData();
        }

        //private void dataGridView_KeyDown(object sender, KeyEventArgs e)
        //{

        //    if (e.KeyCode == Keys.Delete)
        //    {
        //        if (dataGridView.SelectedRows.Count > 0) // 检查是否有选中的行
        //        {
        //            // 弹出提示框，询问用户是否确认删除数据
        //            DialogResult result = MessageBox.Show("确定要删除所有数据吗？", "确认删除", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

        //            if (result == DialogResult.Yes)
        //            {
        //                DataGridViewRow selectedRow = dataGridView.SelectedRows[0];
        //                string productID = selectedRow.Cells[0].Value.ToString();


        //                using (var db = new LiteDatabase(".\\ldatabase.db"))
        //                {

        //                AA:
        //                    using (SQLiteCommand command = new SQLiteCommand("DELETE FROM ProductPrices WHERE ProductID = @productid", connection))
        //                    {
        //                        _ = command.Parameters.AddWithValue("@productid", productID);
        //                        // command.ExecuteNonQuery();
        //                        int rowsAffected = command.ExecuteNonQuery();

        //                        if (rowsAffected > 0)
        //                        {
        //                            _ = MessageBox.Show("操作成功！");
        //                        }
        //                        else
        //                        {
        //                            _ = MessageBox.Show("操作失败！请重试……");
        //                            goto AA;
        //                        }
        //                    }
        //                    connection.Close();
        //                }

        //                RefreshData();
        //            }
        //        }
        //    }
        //}

        private void RefreshData()//刷新数据记录显示
        {
             

            using (var db = new LiteDatabase(".\\ldatabase.db"))
            {
                // 获取ProductPrices集合  
                var ProductPrices = db.GetCollection<BsonDocument>("ProductPrices");

                // 获取ProductPrices数据  
                var ProductPricedata = ProductPrices.FindAll()
                    .Select(doc => new ProductPrice
                    {
                        _id = doc["_id"].AsInt32,
                        ProductType = doc["ProductType"].AsString,
                        process = doc["Process"].AsString,
                        Unit = doc["Unit"].AsString,
                        UnitPrice = doc["UnitPrice"],
                        UnitPricet = doc["UnitPricet"],
                        UnitPrices = doc["Unitprices"],
                        JijiaFangshi = doc["JijiaFangshi"].AsString,
                        lowprice = doc["lowprice"],
                        lwunit = doc["lwunit"].AsString

                    })
                    .ToList();

                // 绑定 DataGridView 控件  
                dataGridView.DataSource = new BindingList<ProductPrice>(ProductPricedata);
             
            }
            jilu.Text = "";
            //producttype.Text = "";
            Process.Text = "";
            unitprice.Text = "0";
            unitpricet.Text = "0";
            unitprices.Text = "0";
            Unit.Text = "";
            lowprice.Text = "0";
            lwunit.Text = "米";
            Jijiafangshi.Text = "面积";
        }


        private void xiala()
        {
            using (SQLiteConnection connection = new SQLiteConnection("Data Source=.\\Database.db;Version=3;"))
            {
                // 打开连接
                connection.Open();
                try
                {
                    // 查询类型名称
                    string sql = "SELECT ProductType FROM CpType";
                    SQLiteCommand cmd = new SQLiteCommand(sql, connection);
                    SQLiteDataReader reader = cmd.ExecuteReader();
                    DataTable dt = new DataTable();
                    dt.Load(reader);

                    // 填充下拉框
                    producttype.DataSource = dt;
                    producttype.DisplayMember = "ProductType";
                    producttype.ValueMember = "ProductType";

                }
                catch (Exception ex)
                {
                    _ = MessageBox.Show("查询类型名称出错：" + ex.Message);
                }
                producttype.SelectedIndex = 0;
                // 关闭连接
                connection.Close();
            }
        }

        private void producttype_SelectedValueChanged(object sender, EventArgs e)

        {
            using (SQLiteConnection connection = new SQLiteConnection("Data Source=.\\Database.db; "))
            {

                if (connection.State != ConnectionState.Open)
                {
                    connection.Open();
                }

                string shangpin = producttype.Text;

                try
                {
                    // 查询类型名称
                    string sql = "SELECT unit FROM CpType WHERE producttype=@producttype";
                    SQLiteCommand cmd = new SQLiteCommand(sql, connection);
                    _ = cmd.Parameters.AddWithValue("@producttype", shangpin);
                    SQLiteDataReader reader = cmd.ExecuteReader();

                    if (reader.Read())
                    {
                        // 直接赋值
                        Unit.Text = reader["unit"].ToString();
                    }
                    else
                    {
                        return;

                    }

                    // 查询jijiafangshi字段
                    string sql2 = "SELECT jijiafangshi FROM CpType WHERE producttype=@producttype";
                    SQLiteCommand cmd2 = new SQLiteCommand(sql2, connection);
                    _ = cmd2.Parameters.AddWithValue("@producttype", shangpin);
                    SQLiteDataReader reader2 = cmd2.ExecuteReader();

                    if (reader2.Read())
                    {
                        // 直接赋值
                        Jijiafangshi.Text = reader2["jijiafangshi"].ToString();
                    }
                    else
                    {
                        _ = MessageBox.Show("未找到jijiafangshi");
                    }
                }
                catch (Exception ex)
                {
                    _ = MessageBox.Show("查询类型名称或jijiafangshi出错：" + ex.Message);
                }

                connection.Close();
            }
        }
    }

}
