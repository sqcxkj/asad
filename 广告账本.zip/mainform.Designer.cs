﻿namespace 广告账本
{
    partial class mainform
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(mainform));
            this.AddRecordButton = new System.Windows.Forms.Button();
            this.QueryButton = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.unpaidListView = new System.Windows.Forms.ListView();
            this.addproduct = new System.Windows.Forms.Button();
            this.addguestname = new System.Windows.Forms.Button();
            this.syssetup = new System.Windows.Forms.Button();
            this.exitbut = new System.Windows.Forms.Button();
            this.shijian = new System.Windows.Forms.Label();
            this.listView1 = new System.Windows.Forms.ListView();
            this.label2 = new System.Windows.Forms.Label();
            this.zt = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // AddRecordButton
            // 
            this.AddRecordButton.Location = new System.Drawing.Point(1135, 83);
            this.AddRecordButton.Name = "AddRecordButton";
            this.AddRecordButton.Size = new System.Drawing.Size(105, 49);
            this.AddRecordButton.TabIndex = 0;
            this.AddRecordButton.Text = "新增订单";
            this.AddRecordButton.UseVisualStyleBackColor = true;
            this.AddRecordButton.Click += new System.EventHandler(this.AddRecordButton_Click);
            // 
            // QueryButton
            // 
            this.QueryButton.Location = new System.Drawing.Point(1135, 158);
            this.QueryButton.Name = "QueryButton";
            this.QueryButton.Size = new System.Drawing.Size(105, 49);
            this.QueryButton.TabIndex = 1;
            this.QueryButton.Text = "查询/删除订单";
            this.QueryButton.UseVisualStyleBackColor = true;
            this.QueryButton.Click += new System.EventHandler(this.QueryButton_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("宋体", 16F);
            this.label1.Location = new System.Drawing.Point(21, 34);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(76, 22);
            this.label1.TabIndex = 2;
            this.label1.Text = "label1";
            // 
            // unpaidListView
            // 
            this.unpaidListView.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.unpaidListView.Font = new System.Drawing.Font("宋体", 14F);
            this.unpaidListView.ForeColor = System.Drawing.Color.Red;
            this.unpaidListView.FullRowSelect = true;
            this.unpaidListView.GridLines = true;
            this.unpaidListView.HideSelection = false;
            this.unpaidListView.Location = new System.Drawing.Point(25, 83);
            this.unpaidListView.Name = "unpaidListView";
            this.unpaidListView.Size = new System.Drawing.Size(365, 409);
            this.unpaidListView.TabIndex = 5;
            this.unpaidListView.UseCompatibleStateImageBehavior = false;
            this.unpaidListView.DoubleClick += new System.EventHandler(this.unpaidListView_DoubleClick);
            // 
            // addproduct
            // 
            this.addproduct.Location = new System.Drawing.Point(1135, 308);
            this.addproduct.Name = "addproduct";
            this.addproduct.Size = new System.Drawing.Size(105, 49);
            this.addproduct.TabIndex = 6;
            this.addproduct.Text = "商品管理";
            this.addproduct.UseVisualStyleBackColor = true;
            this.addproduct.Click += new System.EventHandler(this.addproduct_Click);
            // 
            // addguestname
            // 
            this.addguestname.Location = new System.Drawing.Point(1135, 233);
            this.addguestname.Name = "addguestname";
            this.addguestname.Size = new System.Drawing.Size(105, 49);
            this.addguestname.TabIndex = 7;
            this.addguestname.Text = "客户名称管理";
            this.addguestname.UseVisualStyleBackColor = true;
            this.addguestname.Click += new System.EventHandler(this.addguestname_Click);
            // 
            // syssetup
            // 
            this.syssetup.Location = new System.Drawing.Point(1135, 383);
            this.syssetup.Name = "syssetup";
            this.syssetup.Size = new System.Drawing.Size(105, 49);
            this.syssetup.TabIndex = 8;
            this.syssetup.Text = "系统设置";
            this.syssetup.UseVisualStyleBackColor = true;
            this.syssetup.Click += new System.EventHandler(this.syssetup_Click);
            // 
            // exitbut
            // 
            this.exitbut.BackColor = System.Drawing.Color.Yellow;
            this.exitbut.Font = new System.Drawing.Font("宋体", 19F);
            this.exitbut.ForeColor = System.Drawing.Color.Red;
            this.exitbut.Location = new System.Drawing.Point(1135, 522);
            this.exitbut.Name = "exitbut";
            this.exitbut.Size = new System.Drawing.Size(105, 49);
            this.exitbut.TabIndex = 9;
            this.exitbut.Text = "退出";
            this.exitbut.UseVisualStyleBackColor = false;
            this.exitbut.Click += new System.EventHandler(this.exitbut_Click);
            // 
            // shijian
            // 
            this.shijian.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.shijian.AutoSize = true;
            this.shijian.Location = new System.Drawing.Point(34, 557);
            this.shijian.Name = "shijian";
            this.shijian.Size = new System.Drawing.Size(41, 12);
            this.shijian.TabIndex = 10;
            this.shijian.Text = "label2";
            // 
            // listView1
            // 
            this.listView1.Font = new System.Drawing.Font("宋体", 11F);
            this.listView1.FullRowSelect = true;
            this.listView1.GridLines = true;
            this.listView1.HideSelection = false;
            this.listView1.Location = new System.Drawing.Point(421, 83);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(699, 409);
            this.listView1.TabIndex = 11;
            this.listView1.UseCompatibleStateImageBehavior = false;
            this.listView1.View = System.Windows.Forms.View.Details;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("宋体", 16F);
            this.label2.Location = new System.Drawing.Point(630, 34);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(98, 22);
            this.label2.TabIndex = 12;
            this.label2.Text = "最新订单";
            // 
            // zt
            // 
            this.zt.AutoSize = true;
            this.zt.Location = new System.Drawing.Point(816, 545);
            this.zt.Name = "zt";
            this.zt.Size = new System.Drawing.Size(149, 24);
            this.zt.TabIndex = 13;
            this.zt.Text = "添加记录后，及时点击刷新\r\n查看记录是否添加成功";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.button1.Location = new System.Drawing.Point(713, 533);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(97, 52);
            this.button1.TabIndex = 14;
            this.button1.Text = "刷新";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // mainform
            // 
            this.AllowDrop = true;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1279, 600);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.zt);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.listView1);
            this.Controls.Add(this.shijian);
            this.Controls.Add(this.exitbut);
            this.Controls.Add(this.syssetup);
            this.Controls.Add(this.addguestname);
            this.Controls.Add(this.addproduct);
            this.Controls.Add(this.unpaidListView);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.QueryButton);
            this.Controls.Add(this.AddRecordButton);
            this.ForeColor = System.Drawing.SystemColors.ControlText;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "mainform";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "【创想广告记账单】";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.mainform_FormClosing);
            this.Load += new System.EventHandler(this.mainform_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button AddRecordButton;
        private System.Windows.Forms.Button QueryButton;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ListView unpaidListView;
        private System.Windows.Forms.Button addproduct;
        private System.Windows.Forms.Button addguestname;
        private System.Windows.Forms.Button syssetup;
        private System.Windows.Forms.Button exitbut;
        private System.Windows.Forms.Label shijian;
        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label zt;
        private System.Windows.Forms.Button button1;
    }
}

